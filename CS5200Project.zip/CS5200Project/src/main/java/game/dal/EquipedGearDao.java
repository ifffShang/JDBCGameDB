package game.dal;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import game.model.EquipedGear;
import game.model.Item;
import game.model.Character;

public class EquipedGearDao {
	protected ConnectionManager connectionManager;
	
	private static EquipedGearDao instance = null;
	protected EquipedGearDao() {
		connectionManager = new ConnectionManager();
	}
	public static EquipedGearDao getInstance() {
		if (instance == null) {
			instance = new EquipedGearDao();
		}
		return instance;
	}
	
	public EquipedGear create(EquipedGear equipedGear) throws SQLException{
		String insertEquipedGear = "insert into EquipedGear (characterID, bodySlot, itemID) values (?,?,?)";
		Connection connection = null;
		PreparedStatement insertStmt = null;
		try {
			connection = connectionManager.getConnection();
			insertStmt = connection.prepareStatement(insertEquipedGear);
			insertStmt.setInt(1, equipedGear.getCharacter().getCharacterID());
			insertStmt.setString(2, equipedGear.getBodySlot().toString());
			insertStmt.setInt(3, equipedGear.getItem().getItemID());
			insertStmt.executeUpdate();
			return equipedGear;
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null)
				connection.close();
			if(insertStmt != null)
				insertStmt.close();
		}
	
	}
	public EquipedGear getGearByCharacterAndBodySlot(int characterID, EquipedGear.BodySlot bodySlot) throws SQLException{
		String selectRecLetter = 
				"select characterID, bodySlot, itemID "
				+ "from EquipedGear "
				+ "where characterID = ? and bodySlot=?";
		Connection connection = null;
		PreparedStatement selectStmt = null;
		ResultSet results = null;
		
		try {
			connection = connectionManager.getConnection();
			selectStmt = connection.prepareStatement(selectRecLetter);
			
			selectStmt.setInt(1, characterID);
			selectStmt.setString(2, bodySlot.toString());
			results = selectStmt.executeQuery();
            CharacterDao characterDao = CharacterDao.getInstance();
           	ItemDao itemDAO = ItemDao.getInstance();
			if (results.next()) {
				int itemID = results.getInt("itemID");
				Character character = characterDao.getCharacterByCharacterID(characterID);
				Item item = itemDAO.getItemByitemID(itemID);
				EquipedGear equipedGear = new EquipedGear(character, bodySlot, item);
				return equipedGear;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(selectStmt != null) {
				selectStmt.close();
			}
			if(results != null) {
				results.close();
			}
		}
		return null ;
	}
	
}
