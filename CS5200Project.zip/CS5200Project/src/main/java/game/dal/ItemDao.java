package game.dal;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import game.model.Item;


public class ItemDao {
	protected ConnectionManager connectionManager;
	
	private static ItemDao instance = null;
	protected ItemDao() {
		connectionManager = new ConnectionManager();
	}
	public static ItemDao getInstance() {
		if (instance == null) {
			instance = new ItemDao();
		}
		return instance;
	}
	
	public Item create(Item item) throws SQLException{
		String insertitem = "INSERT INTO item(name, maxStackSize, price, itemLevel) VALUES(?,?,?,?);";
		Connection connection = null;
		PreparedStatement insertStmt = null;
		ResultSet resultKey = null;
		try {
			connection = connectionManager.getConnection();
			insertStmt = connection.prepareStatement(insertitem, Statement.RETURN_GENERATED_KEYS);
			
			insertStmt.setString(1, item.getName());
			insertStmt.setInt(2, item.getMaxStackSize());
			insertStmt.setDouble(3, item.getPrice());
			insertStmt.setInt(4, item.getItemLevel());
			insertStmt.executeUpdate();
			
			resultKey = insertStmt.getGeneratedKeys();
			int itemID = -1;
			if (resultKey.next()) {
				itemID = resultKey.getInt(1);
			}else {
				throw new SQLException("Unable to retrieve auto-generated key.");
			}
			item.setItemID(itemID);
			return item;
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(insertStmt != null) {
				insertStmt.close();
			}
		}
	}
	
	public Item getItemByitemID(int itemID) throws SQLException{
		String selectUser = "SELECT itemID, name, maxStackSize, price, itemLevel FROM Item WHERE itemID = ?;";
		Connection connection = null;
		PreparedStatement selectStmt = null;
		ResultSet results = null;
		try {
			connection = connectionManager.getConnection();
			selectStmt = connection.prepareStatement(selectUser);
			selectStmt.setInt(1, itemID);
			results = selectStmt.executeQuery();
			if (results.next()) {
				String name = results.getString("name");
				int maxStackSize = results.getInt("maxStackSize");
				Double price = results.getDouble("price");
				int itemLevel = results.getInt("itemLevel");
				
				Item item = new Item(itemID, name, maxStackSize, price, itemLevel);
				return item;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(selectStmt != null) {
				selectStmt.close();
			}
			if(results != null) {
				results.close();
			}
		}
		return null;
	}
	
	public void delete(Item item) throws SQLException{
		String deleteItem = "DELETE FROM Item WHERE itemID=?;";
		Connection connection = null;
		PreparedStatement deleteStmt = null;
		try {
			connection = connectionManager.getConnection();
			deleteStmt = connection.prepareStatement(deleteItem);
			deleteStmt.setInt(1, item.getItemID());
			deleteStmt.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(deleteStmt != null) {
				deleteStmt.close();
			}
		}
	}
}
