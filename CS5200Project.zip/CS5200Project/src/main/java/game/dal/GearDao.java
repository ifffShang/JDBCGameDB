package game.dal;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import game.model.Item;
import game.model.Gear;

public class GearDao extends ItemDao {
	private static GearDao instance = null;
	protected GearDao() {
		super();
	}
	public static GearDao getInstance() {
		if (instance == null) {
			instance = new GearDao();
		}
		return instance;
	}

	public Gear create(Gear gear) throws SQLException{

		Item item = create(new Item(gear.getName(), gear.getMaxStackSize(), gear.getPrice(), gear.getItemLevel()));
		
		String insertgear = "INSERT INTO Gear(itemID, requiredBodySlot, defenseRating, magicDefenseRating, requiredLevel) VALUES(?,?,?,?,?)";
		Connection connection = null;
		PreparedStatement insertStmt = null;
		
		try {
			connection = connectionManager.getConnection();
			insertStmt = connection.prepareStatement(insertgear);
			insertStmt.setInt(1, item.getItemID()); 
			insertStmt.setString(2, gear.getBodySlot().toString());
			insertStmt.setInt(3, gear.getDefenseRating());
			insertStmt.setInt(4, gear.getMagicDefenseRating());
			insertStmt.setInt(5, gear.getRequiredLevel());
			insertStmt.executeUpdate();
			gear.setItemID(item.getItemID());
			return gear;
			
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null)
				connection.close();
			if(insertStmt != null)
				insertStmt.close();
		}
		
	}
	public Gear getGearByItemID(int itemID) throws SQLException{
		String selectGear = 
				"SELECT Gear.itemID AS itemID, name, maxStackSize, price, itemLevel, requiredBodySlot, defenseRating, magicDefenseRating, requiredLevel " +
			               "FROM Gear INNER JOIN Item " +
			               "USING (itemID) " +
			               "WHERE Gear.itemID = ?;";
		Connection connection = null;
		PreparedStatement selectStmt = null;
		ResultSet results = null;
		try {
			connection = connectionManager.getConnection();
			selectStmt = connection.prepareStatement(selectGear);
			selectStmt.setInt(1, itemID);
			results = selectStmt.executeQuery();
			if(results.next()) {
				String name = results.getString("name");
				int maxStackSize = results.getInt("maxStackSize");
				Double price = results.getDouble("price");
				Gear.BodySlot bodySlot = Gear.BodySlot.valueOf(results.getString("requiredBodySlot"));
				int itemLevel = results.getInt("itemLevel");
				int defenseRating = results.getInt("defenseRating");
				int magicDefenseRating = results.getInt("magicDefenseRating");
				int requiredLevel = results.getInt("requiredLevel");

				Gear Gear = new Gear(itemID, name, maxStackSize, price, itemLevel, bodySlot, defenseRating, magicDefenseRating, requiredLevel);				
				return Gear;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(selectStmt != null) {
				selectStmt.close();
			}
			if(results != null) {
				results.close();
			}
		}
		return null;
	}
}
