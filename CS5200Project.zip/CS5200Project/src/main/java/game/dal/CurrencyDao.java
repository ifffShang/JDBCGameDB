package game.dal;

import game.model.Currency;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class CurrencyDao {
    
    protected ConnectionManager connectionManager;
    
    private static CurrencyDao instance = null;
    
    public CurrencyDao() {
        connectionManager = new ConnectionManager();
    }
    
    public static CurrencyDao getInstance() {
        if(instance == null) {
            instance = new CurrencyDao();
        }
        return instance;
    }
    
    public Currency create(Currency currency) throws SQLException {
        
        String insertCurrency = "INSERT INTO Currency(name,description,cap,weeklyCap) VALUES(?,?,?,?);";
        Connection connection = null;
        PreparedStatement insertStmt = null;
        ResultSet resultKey = null;
        
        try {
            connection = connectionManager.getConnection();
            insertStmt = connection.prepareStatement(insertCurrency,
                    Statement.RETURN_GENERATED_KEYS);
            
            insertStmt.setString(1, currency.getName());
            insertStmt.setString(2, currency.getDescription());
            insertStmt.setInt(3, currency.getCap());
            insertStmt.setInt(4, currency.getWeeklyCap());
            insertStmt.executeUpdate();
            
            resultKey = insertStmt.getGeneratedKeys();
            int currencyID = -1;
            if(resultKey.next()) {
                currencyID = resultKey.getInt(1);
            } else {
                throw new SQLException("Unable to retrieve auto-generated key.");
            }
            currency.setCurrencyID(currencyID);
            return currency;
            
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        } finally {
            if(connection != null) {
                connection.close();
            }
            if(insertStmt != null) {
                insertStmt.close();
            }
            if(resultKey != null) {
                resultKey.close();
            }
        }
    }
    
    public Currency getCurrencyByID(int currencyID) throws SQLException {
        String selectCurrency =
                "SELECT currencyID, name, description, cap, weeklyCap FROM Currency WHERE currencyID=?;";
        Connection connection = null;
        PreparedStatement selectStmt = null;
        ResultSet results = null;
        try {
            connection = connectionManager.getConnection();
            selectStmt = connection.prepareStatement(selectCurrency);
            selectStmt.setInt(1, currencyID);
            results = selectStmt.executeQuery();
            if(results.next()) {
                int resultCurrencyID = results.getInt("currencyID");
                String name = results.getString("name");
                String description = results.getString("description");
                int cap = results.getInt("cap");
                Integer weeklyCap = results.getInt("weeklyCap");
                if (results.wasNull()) {
                    weeklyCap = null;
                }
                Currency currency = new Currency(resultCurrencyID, name, description, cap, weeklyCap);
                return currency;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        } finally {
            if(connection != null) {
                connection.close();
            }
            if(selectStmt != null) {
                selectStmt.close();
            }
            if(results != null) {
                results.close();
            }
        }
        
        return null;
    }
}
