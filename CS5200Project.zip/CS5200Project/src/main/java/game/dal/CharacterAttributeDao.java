package game.dal;

import java.sql.Connection;
import game.model.Character;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import game.model.CharacterAttribute;

public class CharacterAttributeDao {
	protected ConnectionManager connectionManager;
	
	private static CharacterAttributeDao instance = null;
	protected  CharacterAttributeDao() {
		connectionManager = new ConnectionManager();
	}
	public static CharacterAttributeDao getInstance() {
		if (instance == null) {
			instance = new CharacterAttributeDao();
		}
		return instance;
	}
	
	public CharacterAttribute create(CharacterAttribute characterAttribute) throws SQLException{
		String insertCharacterAttribute = "insert into CharacterAttribute (characterID, attribute, value) values (?,?,?)";
		Connection connection = null;
		PreparedStatement insertStmt = null;
		try {
			connection = connectionManager.getConnection();
			insertStmt = connection.prepareStatement(insertCharacterAttribute);
			insertStmt.setInt(1, characterAttribute.getCharacter().getCharacterID());
			insertStmt.setString(2, characterAttribute.getAttribute().toString());
			insertStmt.setInt(3, characterAttribute.getValue());
			insertStmt.executeUpdate();
			return characterAttribute;
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null)
				connection.close();
			if(insertStmt != null)
				insertStmt.close();
		}
	
	}
	public CharacterAttribute getCharacterAttributeByCharacterIDAndAttribute(int characterID, CharacterAttribute.Attribute attribute) throws SQLException{
		String selectCharacterAttribute = 
				"select characterID, attribute, value "
				+ "from characterAttribute "
				+ "where characterID = ? and attribute=?";
		Connection connection = null;
		PreparedStatement selectStmt = null;
		ResultSet results = null;
		
		try {
			connection = connectionManager.getConnection();
			selectStmt = connection.prepareStatement(selectCharacterAttribute);
			
			selectStmt.setInt(1, characterID);
			selectStmt.setString(2, attribute.toString());
			results = selectStmt.executeQuery();
            CharacterDao characterDao = CharacterDao.getInstance();
			if (results.next()) {
				int value = results.getInt("value");
                Character character = characterDao.getCharacterByCharacterID(characterID);
				CharacterAttribute characterAttribute = new CharacterAttribute(character, attribute, value);	
				return characterAttribute;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(selectStmt != null) {
				selectStmt.close();
			}
			if(results != null) {
				results.close();
			}
		}
		return null ;
	}
	
}
