package game.dal;

import game.model.*;
import game.model.Character;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


public class CharacterDao {
	
	protected ConnectionManager connectionManager;
	
	private static CharacterDao instance = null;
	
	public CharacterDao() {
		connectionManager = new ConnectionManager();
	}
	
	public static CharacterDao getInstance() {
		if(instance == null) {
			instance = new CharacterDao();
		}
		return instance;
	}
	
	public Character create(Character character) throws SQLException {
		
		String insertCharacter = "INSERT INTO `Character`(playerID,firstName,lastName) VALUES(?,?,?);";
		Connection connection = null;
		PreparedStatement insertStmt = null;
		ResultSet resultKey = null;
		
		try {
			connection = connectionManager.getConnection();
			insertStmt = connection.prepareStatement(insertCharacter,
					Statement.RETURN_GENERATED_KEYS);
			
			insertStmt.setInt(1, character.getPlayer().getPlayerID());
			insertStmt.setString(2, character.getFirstName());
			insertStmt.setString(3, character.getLastName());
			insertStmt.executeUpdate();


			resultKey = insertStmt.getGeneratedKeys();
			int characterID = -1;
			if(resultKey.next()) {
				characterID = resultKey.getInt(1);
			} else {
				throw new SQLException("Unable to retrieve auto-generated key.");
			}
			character.setCharacterID(characterID);
			return character;
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
	        if (resultKey != null) {
	            resultKey.close();
	        }
	        if (insertStmt != null) {
	            insertStmt.close();
	        }
	        if (connection != null) {
	            connection.close();
	        }}
		}
	

	public Character getCharacterByCharacterID(int characterID) throws SQLException {
		String selectCharacter =
				"SELECT characterID,playerID,firstName,lastName,mainHandWeapon FROM `Character` WHERE characterID=?;";
			Connection connection = null;
			PreparedStatement selectStmt = null;
			ResultSet results = null;
			try {
				connection = connectionManager.getConnection();
				selectStmt = connection.prepareStatement(selectCharacter);
				selectStmt.setInt(1, characterID);
				results = selectStmt.executeQuery();
				PlayerDao playerDao = PlayerDao.getInstance();
				WeaponDao weaponDao = WeaponDao.getInstance();
				if(results.next()) {
					int resultCharacterID = results.getInt("characterID"); 
					Player player = playerDao.getPlayerByID(results.getInt("playerID"));
					String firstName = results.getString("firstName");
					String lastName = results.getString("lastName");
					Weapon mainHandWeapon = weaponDao.getWeaponByItemID(results.getInt("mainHandWeapon"));
					Character character = new Character(resultCharacterID,player,firstName,lastName,mainHandWeapon);
					return character;
				}
			} catch (SQLException e) {
				e.printStackTrace();
				throw e;
			} finally {
				if(connection != null) {
					connection.close();
				}
				if(selectStmt != null) {
					selectStmt.close();
				}
				if(results != null) {
					results.close();
				}
			}
			
			return null ;
	}
	
	public List<Character> getCharacterByMainHandWeapon(int weaponID) throws SQLException{
		List<Character> characters = new ArrayList<Character>();
		String selectCharacter =
				"SELECT characterID,playerID,firstName,lastName,mainHandWeapon FROM `Character` WHERE mainHandWeapon=?;";
		Connection connection = null;
		PreparedStatement selectStmt = null;
		ResultSet results = null;
		try {
			connection = connectionManager.getConnection();
			selectStmt = connection.prepareStatement(selectCharacter);
			
			selectStmt.setInt(1, weaponID);
			results = selectStmt.executeQuery();
			
			PlayerDao playerDao = PlayerDao.getInstance();
			WeaponDao weaponDao = WeaponDao.getInstance();
			
			while(results.next()) {
				int characterID = results.getInt("characterID"); 
				Player player = playerDao.getPlayerByID(results.getInt("playerID"));
				String firstName = results.getString("firstName");
				String lastName = results.getString("lastName");
				Weapon mainHandWeapon = weaponDao.getWeaponByItemID(results.getInt("mainHandWeapon"));
				
				Character character = new Character(characterID,player,firstName,lastName,mainHandWeapon);
				characters.add(character);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(selectStmt != null) {
				selectStmt.close();
			}
			if(results != null) {
				results.close();
			}
		}
		return characters;
	}
}
