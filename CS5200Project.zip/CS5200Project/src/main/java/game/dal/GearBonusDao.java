package game.dal;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import game.model.Gear;
import game.model.GearBonus;

public class GearBonusDao {
	protected ConnectionManager connectionManager;
	
	private static GearBonusDao instance = null;
	protected GearBonusDao() {
		connectionManager = new ConnectionManager();
	}
	public static GearBonusDao getInstance() {
		if (instance == null) {
			instance = new GearBonusDao();
		}
		return instance;
	}
	
	public GearBonus create(GearBonus gearBonus) throws SQLException{
		String insertGearBonus = "insert into GearBonus (gearID, attribute, bonus) values (?,?,?)";
		Connection connection = null;
		PreparedStatement insertStmt = null;
		try {
			connection = connectionManager.getConnection();
			insertStmt = connection.prepareStatement(insertGearBonus);
			insertStmt.setInt(1, gearBonus.getGear().getItemID());
			insertStmt.setString(2, gearBonus.getAttribute().toString());
			insertStmt.setInt(3, gearBonus.getBonus());
			insertStmt.executeUpdate();
			return gearBonus;
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null)
				connection.close();
			if(insertStmt != null)
				insertStmt.close();
		}
	
	}
	public GearBonus getGearBonusByGearIDAndAttribute(int gearID, GearBonus.Attribute attribute) throws SQLException{
		String selectGearBonus = 
				"select gearID, attribute, bonus "
				+ "from GearBonus "
				+ "where gearID = ? and attribute=?";
		Connection connection = null;
		PreparedStatement selectStmt = null;
		ResultSet results = null;
		
		try {
			connection = connectionManager.getConnection();
			selectStmt = connection.prepareStatement(selectGearBonus);
			
			selectStmt.setInt(1, gearID);
			selectStmt.setString(2, attribute.toString());
			results = selectStmt.executeQuery();
            GearDao gearDAO = GearDao.getInstance();
			if (results.next()) {
				int value = results.getInt("bonus");
				Gear gear = gearDAO.getGearByItemID(gearID);
				GearBonus gearBonus = new GearBonus(gear, attribute, value);	
				return gearBonus;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(selectStmt != null) {
				selectStmt.close();
			}
			if(results != null) {
				results.close();
			}
		}
		return null ;
	}
}
