package game.dal;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import game.model.Character;
import game.model.CharacterItem;
import game.model.Item;

public class CharacterItemDao {
protected ConnectionManager connectionManager;
	
	private static CharacterItemDao instance = null;
	
	public CharacterItemDao() {
		connectionManager = new ConnectionManager();
	}
	
	public static CharacterItemDao getInstance() {
		if(instance == null) {
			instance = new CharacterItemDao();
		}
		return instance;
	}
	
	public CharacterItem create(CharacterItem characterItem) throws SQLException {
		
		String insertCharacterItem = "INSERT INTO CharacterItem(characterID,slotID,itemID,quantity) VALUES(?,?,?,?);";
		Connection connection = null;
		PreparedStatement insertStmt = null;
		try {
			connection = connectionManager.getConnection();
			insertStmt = connection.prepareStatement(insertCharacterItem);
			insertStmt.setInt(1, characterItem.getCharacter().getCharacterID());
			insertStmt.setInt(2, characterItem.getSlotID());
			insertStmt.setInt(3, characterItem.getItem().getItemID());
			insertStmt.setInt(4, characterItem.getQuantity());
			insertStmt.executeUpdate();
			return characterItem;
			
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(insertStmt != null) {
				insertStmt.close();
			}
		}
	}

	public CharacterItem getCharacterByCharacterIDAndSlotID(int characterID, int slotID) throws SQLException {
		String selectCharacterItem =
				"SELECT characterID,slotID,itemID,quantity FROM CharacterItem WHERE characterID=? and slotID = ?;";
			Connection connection = null;
			PreparedStatement selectStmt = null;
			ResultSet results = null;
			try {
				connection = connectionManager.getConnection();
				selectStmt = connection.prepareStatement(selectCharacterItem);
				selectStmt.setInt(1, characterID);
				selectStmt.setInt(2, slotID);
				results = selectStmt.executeQuery();
				
				ItemDao itemDao = ItemDao.getInstance();
				CharacterDao characterDao = CharacterDao.getInstance();
				
				if(results.next()) {
					
					Item item = itemDao.getItemByitemID(results.getInt("itemID"));
					int quantity = results.getInt("quantity");
					Character character = characterDao.getCharacterByCharacterID(characterID);
					CharacterItem characterItem = new CharacterItem(character,slotID,item,quantity);
					return characterItem;
				}
			} catch (SQLException e) {
				e.printStackTrace();
				throw e;
			} finally {
				if(connection != null) {
					connection.close();
				}
				if(selectStmt != null) {
					selectStmt.close();
				}
				if(results != null) {
					results.close();
				}
			}
			
			return null ;
	}
}
