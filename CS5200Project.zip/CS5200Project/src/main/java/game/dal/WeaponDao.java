package game.dal;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import game.model.Weapon;
import game.model.Item;
import game.model.Character;



public class WeaponDao extends ItemDao {
	private static WeaponDao instance = null;
	protected WeaponDao() {
		super();
	}
	public static WeaponDao getInstance() {
		if (instance == null) {
			instance = new WeaponDao();
		}
		return instance;
	}
	
	public Weapon create(Weapon weapon) throws SQLException{

		Item item = create(new Item(weapon.getName(), weapon.getMaxStackSize(), weapon.getPrice(), weapon.getItemLevel()));
		
		String insertweapon = "INSERT INTO Weapon(itemID,physicalDamage,magicDamage,autoAttack,delay,requiredLevel) VALUES(?,?,?,?,?,?)";
		Connection connection = null;
		PreparedStatement insertStmt = null;
		
		try {
			connection = connectionManager.getConnection();
			insertStmt = connection.prepareStatement(insertweapon);
			insertStmt.setInt(1, item.getItemID()); 
			insertStmt.setInt(2, weapon.getPhysicalDamage());
			insertStmt.setInt(3, weapon.getMagicDamage());
			insertStmt.setInt(4, weapon.getAutoAttack());
			insertStmt.setInt(5, weapon.getDelay());
			insertStmt.setInt(6, weapon.getRequiredLevel());
			insertStmt.executeUpdate();
			weapon.setItemID(item.getItemID());
			return weapon;
			
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null)
				connection.close();
			if(insertStmt != null)
				insertStmt.close();
		}
		
	}
	public Weapon getWeaponByItemID(int itemID) throws SQLException{
		String selectweapon = 
				"SELECT weapon.itemID AS itemID, name, maxStackSize, price, itemLevel, physicalDamage,magicDamage,autoAttack,delay,requiredLevel " +
			               "FROM weapon INNER JOIN Item " +
			               "USING (itemID) " +
			               "WHERE weapon.itemID = ?;";
		Connection connection = null;
		PreparedStatement selectStmt = null;
		ResultSet results = null;
		try {
			connection = connectionManager.getConnection();
			selectStmt = connection.prepareStatement(selectweapon);
			selectStmt.setInt(1, itemID);
			results = selectStmt.executeQuery();
			if(results.next()) {
				String name = results.getString("name");
				int maxStackSize = results.getInt("maxStackSize");
				Double price = results.getDouble("price");
				int itemLevel = results.getInt("itemLevel");
				int physicalDamage = results.getInt("physicalDamage");
				int magicDamage = results.getInt("magicDamage");
				int autoAttack = results.getInt("autoAttack");
				int delay = results.getInt("delay");
				int requiredLevel = results.getInt("requiredLevel");

				Weapon weapon = new Weapon(itemID, name, maxStackSize, price, itemLevel, physicalDamage,magicDamage,autoAttack,delay,requiredLevel);				
				
				return weapon;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(selectStmt != null) {
				selectStmt.close();
			}
			if(results != null) {
				results.close();
			}
		}
		return null;
	}
	public Weapon getWeaponByName(String name) throws SQLException{
		String selectweapon = 
				"SELECT weapon.itemID AS itemID, name, maxStackSize, price, itemLevel, physicalDamage,magicDamage,autoAttack,delay,requiredLevel " +
						"FROM weapon INNER JOIN Item " +
						"USING (itemID) " +
						"WHERE weapon.name = ?;";
		Connection connection = null;
		PreparedStatement selectStmt = null;
		ResultSet results = null;
		try {
			connection = connectionManager.getConnection();
			selectStmt = connection.prepareStatement(selectweapon);
			selectStmt.setString(1, name);
			results = selectStmt.executeQuery();
			if(results.next()) {
				int itemID = results.getInt("itemID");
				int maxStackSize = results.getInt("maxStackSize");
				Double price = results.getDouble("price");
				int itemLevel = results.getInt("itemLevel");
				int physicalDamage = results.getInt("physicalDamage");
				int magicDamage = results.getInt("magicDamage");
				int autoAttack = results.getInt("autoAttack");
				int delay = results.getInt("delay");
				int requiredLevel = results.getInt("requiredLevel");
				
				Weapon weapon = new Weapon(itemID, name, maxStackSize, price, itemLevel, physicalDamage,magicDamage,autoAttack,delay,requiredLevel);				
				
				return weapon;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(selectStmt != null) {
				selectStmt.close();
			}
			if(results != null) {
				results.close();
			}
		}
		return null;
	}
	
    public List<Weapon> getWeaponsListByItemLevel(int itemLevel) throws SQLException {
        List<Weapon> weapons = new ArrayList<>();
        String selectWeapons = 
            "SELECT Weapon.itemID, Item.name, Item.maxStackSize, Item.price, Item.itemLevel, " +
            "Weapon.physicalDamage, Weapon.magicDamage, Weapon.autoAttack, Weapon.delay, Weapon.requiredLevel " +
            "FROM Weapon INNER JOIN Item ON Weapon.itemID = Item.itemID " +
            "WHERE itemLevel = ?;";

        Connection connection = null;
        PreparedStatement selectStmt = null;
        ResultSet results = null;
        try {
            connection = connectionManager.getConnection();
            selectStmt = connection.prepareStatement(selectWeapons);
            selectStmt.setInt(1, itemLevel);
            
            results = selectStmt.executeQuery();
            while (results.next()) {
                int foundItemID = results.getInt("itemID");
                String name = results.getString("name");
                int maxStackSize = results.getInt("maxStackSize");
                Double price = results.getDouble("price");
                int resultItemLevel = results.getInt("itemLevel");
                int physicalDamage = results.getInt("physicalDamage");
                int magicDamage = results.getInt("magicDamage");
                int autoAttack = results.getInt("autoAttack");
                int delay = results.getInt("delay");
                int requiredLevel = results.getInt("requiredLevel");

                Weapon weapon = new Weapon(foundItemID, name, maxStackSize, price, resultItemLevel, physicalDamage, magicDamage, autoAttack, delay, requiredLevel);
                weapons.add(weapon);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        } finally {
            if (results != null) {
                results.close();
            }
            if (selectStmt != null) {
                selectStmt.close();
            }
            if (connection != null) {
                connection.close();
            }
        }
        return weapons;
    }
    
    public Weapon updateWeapon(Weapon weapon, int newRequiredLevel) throws SQLException {
        String updateWeaponStmt = "UPDATE Weapon SET requiredLevel=? WHERE itemID=?;";
        Connection connection = null;
        PreparedStatement updateStmt = null;
        try {
            connection = connectionManager.getConnection();
            updateStmt = connection.prepareStatement(updateWeaponStmt);
            updateStmt.setInt(1, newRequiredLevel);
            updateStmt.setInt(2, weapon.getItemID());
            updateStmt.executeUpdate();
            weapon.setRequiredLevel(newRequiredLevel);
            return weapon;
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        } finally {
            if (updateStmt != null) {
                updateStmt.close();
            }
            if (connection != null) {
                connection.close();
            }
        }
    }


    public void deleteWeapon(Weapon weapon) throws SQLException {
        if (weapon.getItemID() == 1) {
            throw new IllegalArgumentException("You are not allowed to delete `Weapon1`");
        } else {
    	        String deleteItemStmt = "DELETE FROM Item WHERE itemID=?;";
    	        Connection connection = null;
    	        PreparedStatement deleteStmt = null;
    	        List<Character> effectedCharacters = new ArrayList<Character>();
    			CharacterDao characterDao = CharacterDao.getInstance();
    			
    	        try {
    	            connection = connectionManager.getConnection();
    	            deleteStmt = connection.prepareStatement(deleteItemStmt);
    	            deleteStmt.setInt(1, weapon.getItemID());
    	            effectedCharacters = characterDao.getCharacterByMainHandWeapon(weapon.getItemID());
    	            int affectedRows = deleteStmt.executeUpdate();
    				
    				if (affectedRows == 0) {
    					throw new SQLException("No records available to delete for itemID=" + weapon.getItemID());
    				}
    				super.delete(weapon);
    				for (Character c: effectedCharacters) {
    					c.setMainHandWeapon(WeaponDao.getInstance().getWeaponByItemID(1));
    				}
    				

    			} catch (SQLException e) {
    				e.printStackTrace();
    				throw e;
    			} finally {
    				if(connection != null) {
    					connection.close();
    				}
    				if(deleteStmt != null) {
    					deleteStmt.close();
    				}
    	        }
    		}

    }
    
    public List<Weapon> getWeaponsByName(String name) throws SQLException {
        List<Weapon> weapons = new ArrayList<Weapon>();
        String selectWeapons = "SELECT Weapon.itemID, Item.name, Item.maxStackSize, Item.price, Item.itemLevel,\n"
        		+ "Weapon.physicalDamage, Weapon.magicDamage, Weapon.autoAttack, Weapon.delay, Weapon.requiredLevel\n"
        		+ "FROM Weapon\n"
        		+ "INNER JOIN Item ON Weapon.itemID = Item.itemID\n"
        		+ "WHERE Item.name LIKE ?;\n"
        		+ "";
        Connection connection = null;
        PreparedStatement selectStmt = null;
        ResultSet results = null;
        try {
            connection = connectionManager.getConnection();
            selectStmt = connection.prepareStatement(selectWeapons);
            selectStmt.setString(1, "%" + name + "%");
            results = selectStmt.executeQuery();
            while (results.next()) {
                int itemID = results.getInt("itemID");
                String resultName = results.getString("name");
                int maxStackSize = results.getInt("maxStackSize");
                double price = results.getDouble("price");
                int itemLevel = results.getInt("itemLevel");
                int physicalDamage = results.getInt("physicalDamage");
                int magicDamage = results.getInt("magicDamage");
                int autoAttack = results.getInt("autoAttack");
                int delay = results.getInt("delay");
                int requiredLevel = results.getInt("requiredLevel");
                Weapon weapon = new Weapon(itemID, resultName, maxStackSize, price, itemLevel, physicalDamage, magicDamage, autoAttack, delay, requiredLevel);
                weapons.add(weapon);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (selectStmt != null) {
                selectStmt.close();
            }
            if (results != null) {
                results.close();
            }
        }
        return weapons;
    }


}
