package game.dal;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import game.model.Consumable;
import game.model.ConsumableBonus;

public class ConsumableBonusDao {
	protected ConnectionManager connectionManager;
	
	private static ConsumableBonusDao instance = null;
	protected  ConsumableBonusDao() {
		connectionManager = new ConnectionManager();
	}
	public static ConsumableBonusDao getInstance() {
		if (instance == null) {
			instance = new ConsumableBonusDao();
		}
		return instance;
	}
	
	public ConsumableBonus create(ConsumableBonus ConsumableBonus) throws SQLException{
		String insertConsumableBonus = "insert into ConsumableBonus (consumableID, attribute, bonus, cap) values (?,?,?,?)";
		Connection connection = null;
		PreparedStatement insertStmt = null;
		try {
			connection = connectionManager.getConnection();
			insertStmt = connection.prepareStatement(insertConsumableBonus);
			insertStmt.setInt(1, ConsumableBonus.getConsumable().getItemID());
			insertStmt.setString(2, ConsumableBonus.getAttribute().toString());
			insertStmt.setInt(3, ConsumableBonus.getBonus());
			insertStmt.setInt(4, ConsumableBonus.getCap());
			insertStmt.executeUpdate();
			return ConsumableBonus;
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null)
				connection.close();
			if(insertStmt != null)
				insertStmt.close();
		}
	
	}
	public ConsumableBonus getConsumableBonusByConsumableIDAndAttribute(int consumableID, ConsumableBonus.Attribute attribute) throws SQLException{
		String selectConsumableBonus = 
				"select consumableID, attribute, bonus,cap "
				+ "from ConsumableBonus "
				+ "where consumableID = ? and attribute=?";
		Connection connection = null;
		PreparedStatement selectStmt = null;
		ResultSet results = null;
		
		try {
			connection = connectionManager.getConnection();
			selectStmt = connection.prepareStatement(selectConsumableBonus);
			
			selectStmt.setInt(1, consumableID);
			selectStmt.setString(2, attribute.toString());
			results = selectStmt.executeQuery();
			ConsumableDao consumableDao = ConsumableDao.getInstance();
			if (results.next()) {
				int value = results.getInt("bonus");
				int cap = results.getInt("cap");
				Consumable consumable = consumableDao.getConsumableByItemID(consumableID);
				ConsumableBonus ConsumableBonus = new ConsumableBonus(consumable, attribute, value, cap);	
				return ConsumableBonus;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(selectStmt != null) {
				selectStmt.close();
			}
			if(results != null) {
				results.close();
			}
		}
		return null ;
	}
}
