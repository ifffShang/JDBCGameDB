package game.dal;

import game.model.Gear;
import game.model.GearAllowedJob;
import game.model.Job;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class GearAllowedJobDao {
    
    protected ConnectionManager connectionManager;
    
    private static GearAllowedJobDao instance = null;
    
    public GearAllowedJobDao() {
        connectionManager = new ConnectionManager();
    }
    
    public static GearAllowedJobDao getInstance() {
        if(instance == null) {
            instance = new GearAllowedJobDao();
        }
        return instance;
    }
    
    public GearAllowedJob create(GearAllowedJob gearAllowedJob) throws SQLException {
        
        String insertGearAllowedJob = "INSERT INTO GearAllowedJob(jobID, gearID) VALUES(?, ?);";
        Connection connection = null;
        PreparedStatement insertStmt = null;
        
        try {
            connection = connectionManager.getConnection();
            insertStmt = connection.prepareStatement(insertGearAllowedJob);
            
            insertStmt.setInt(1, gearAllowedJob.getJob().getJobID());
            insertStmt.setInt(2, gearAllowedJob.getGear().getItemID());
            insertStmt.executeUpdate();
            
            return gearAllowedJob;
            
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        } finally {
            if(connection != null) {
                connection.close();
            }
            if(insertStmt != null) {
                insertStmt.close();
            }
        }
    }
    
    public GearAllowedJob getGearAllowedJobByID(int jobID, int gearID) throws SQLException {
        String selectGearAllowedJob = "SELECT jobID, gearID FROM GearAllowedJob WHERE jobID = ? AND gearID = ?;";
        Connection connection = null;
        PreparedStatement selectStmt = null;
        ResultSet results = null;
        try {
            connection = connectionManager.getConnection();
            selectStmt = connection.prepareStatement(selectGearAllowedJob);
            selectStmt.setInt(1, jobID);
            selectStmt.setInt(2, gearID);
            results = selectStmt.executeQuery();
            JobDao jobDao = JobDao.getInstance();
            GearDao gearDao = GearDao.getInstance();
            
            if(results.next()) {
		        	Job job = jobDao.getJobByID(jobID);
		        	Gear gear = gearDao.getGearByItemID(gearID);
	            GearAllowedJob gearAllowedJob = new GearAllowedJob(job, gear);
	            return gearAllowedJob;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        } finally {
            if(connection != null) {
                connection.close();
            }
            if(selectStmt != null) {
                selectStmt.close();
            }
            if(results != null) {
                results.close();
            }
        }
        
        return null;
    }
}
