package game.dal;

import game.model.CharacterCurrency;
import game.model.Currency;
import game.model.Character;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class CharacterCurrencyDao {
    
    protected ConnectionManager connectionManager;
    
    private static CharacterCurrencyDao instance = null;
    
    public CharacterCurrencyDao() {
        connectionManager = new ConnectionManager();
    }
    
    public static CharacterCurrencyDao getInstance() {
        if(instance == null) {
            instance = new CharacterCurrencyDao();
        }
        return instance;
    }
    
    public CharacterCurrency create(CharacterCurrency characterCurrency) throws SQLException {
        
        String insertCharacterCurrency = "INSERT INTO CharacterCurrency(characterID,currencyID,ownedAmount,weeklyOwnedAmount) VALUES(?,?,?,?);";
        Connection connection = null;
        PreparedStatement insertStmt = null;
        
        try {
            connection = connectionManager.getConnection();
            insertStmt = connection.prepareStatement(insertCharacterCurrency);
            
            insertStmt.setInt(1, characterCurrency.getCharacter().getCharacterID());
            insertStmt.setInt(2, characterCurrency.getCurrency().getCurrencyID());
            insertStmt.setInt(3, characterCurrency.getOwnedAmount());
            insertStmt.setInt(4, characterCurrency.getWeeklyOwnedAmount());
            insertStmt.executeUpdate();         
            return characterCurrency;
            
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        } finally {
            if(connection != null) {
                connection.close();
            }
            if(insertStmt != null) {
                insertStmt.close();
            }
        }
    }
    
    public CharacterCurrency getCharacterCurrencyByID(int characterID, int currencyID) throws SQLException {
        String selectCharacterCurrency =
                "SELECT characterID, currencyID, ownedAmount, weeklyOwnedAmount FROM CharacterCurrency WHERE characterID=? AND currencyID=?;";
        Connection connection = null;
        PreparedStatement selectStmt = null;
        ResultSet results = null;
        try {
            connection = connectionManager.getConnection();
            selectStmt = connection.prepareStatement(selectCharacterCurrency);
            selectStmt.setInt(1, characterID);
            selectStmt.setInt(2, currencyID);
            results = selectStmt.executeQuery();
            
            CharacterDao characterDao = CharacterDao.getInstance();
            CurrencyDao currencyDao = CurrencyDao.getInstance();
            
            if(results.next()) {
                
                int ownedAmount = results.getInt("ownedAmount");
                Integer weeklyOwnedAmount = results.getInt("weeklyOwnedAmount");
                Character character = characterDao.getCharacterByCharacterID(characterID);
                Currency currency = currencyDao.getCurrencyByID(currencyID);
                
                CharacterCurrency characterCurrency = new CharacterCurrency(currency, character, ownedAmount, weeklyOwnedAmount);
                return characterCurrency;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        } finally {
            if(connection != null) {
                connection.close();
            }
            if(selectStmt != null) {
                selectStmt.close();
            }
            if(results != null) {
                results.close();
            }
        }
        
        return null;
    }
}
