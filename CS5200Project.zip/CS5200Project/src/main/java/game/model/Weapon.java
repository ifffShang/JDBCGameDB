package game.model;

public class Weapon extends Item{
	protected int physicalDamage;
	protected int magicDamage;
	protected int autoAttack;
	protected int delay;
	protected int requiredLevel;
	
	public Weapon(int itemID, String name, int maxStackSize, double price, int itemLevel, int physicalDamage,
			int magicDamage, int autoAttack, int delay, int requiredLevel) {
		super(itemID, name, maxStackSize, price, itemLevel);
		this.physicalDamage = physicalDamage;
		this.magicDamage = magicDamage;
		this.autoAttack = autoAttack;
		this.delay = delay;
		this.requiredLevel = requiredLevel;
	}

	public Weapon(String name, int maxStackSize, double price, int itemLevel, int physicalDamage, int magicDamage,
			int autoAttack, int delay, int requiredLevel) {
		super(name, maxStackSize, price, itemLevel);
		this.physicalDamage = physicalDamage;
		this.magicDamage = magicDamage;
		this.autoAttack = autoAttack;
		this.delay = delay;
		this.requiredLevel = requiredLevel;
	}


	public Weapon(int itemID) {
		super(itemID);
	}


	public int getPhysicalDamage() {
		return physicalDamage;
	}


	public void setPhysicalDamage(int physicalDamage) {
		this.physicalDamage = physicalDamage;
	}


	public int getMagicDamage() {
		return magicDamage;
	}


	public void setMagicDamage(int magicDamage) {
		this.magicDamage = magicDamage;
	}


	public int getAutoAttack() {
		return autoAttack;
	}


	public void setAutoAttack(int autoAttack) {
		this.autoAttack = autoAttack;
	}


	public int getDelay() {
		return delay;
	}


	public void setDelay(int delay) {
		this.delay = delay;
	}


	public int getRequiredLevel() {
		return requiredLevel;
	}


	public void setRequiredLevel(int requiredLevel) {
		this.requiredLevel = requiredLevel;
	}


	
	
}
