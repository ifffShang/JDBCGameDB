package game.model;

public class Item {
	protected int itemID;
	protected String name;
	protected int maxStackSize;
	protected double price;
	protected int itemLevel;
	public Item(int itemID, String name, int maxStackSize, double price, int itemLevel) {
		this.itemID = itemID;
		this.name = name;
		this.maxStackSize = maxStackSize;
		this.price = price;
		this.itemLevel = itemLevel;
	}

	public Item(String name, int maxStackSize, double price, int itemLevel) {
		this.name = name;
		this.maxStackSize = maxStackSize;
		this.price = price;
		this.itemLevel = itemLevel;
	}
	
	
	public Item(int itemID) {
		this.itemID = itemID;
	}
	

	public int getItemID() {
		return itemID;
	}

	public void setItemID(int itemID) {
		this.itemID = itemID;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getMaxStackSize() {
		return maxStackSize;
	}
	public void setMaxStackSize(int maxStackSize) {
		this.maxStackSize = maxStackSize;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getItemLevel() {
		return itemLevel;
	}
	public void setItemLevel(int itemLevel) {
		this.itemLevel = itemLevel;
	}
	
	
}
