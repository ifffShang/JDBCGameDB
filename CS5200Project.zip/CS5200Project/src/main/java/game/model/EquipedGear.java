package game.model;

public class EquipedGear {
	protected Character character;
	public enum BodySlot {
		head, body, hand, legs, feet, off_hand, earring, wrist, ring
	}
	protected Item item;
	protected BodySlot bodySlot;
	public EquipedGear(Character character, BodySlot bodySlot, Item item) {
		this.character = character;
		this.item = item;
		this.bodySlot = bodySlot;
	}
//	public EquipedGear(Character character, BodySlot bodySlot) {
//		this.character = character;
//		this.bodySlot = bodySlot;
//	}
//	public EquipedGear(Item item) {
//		this.item = item;
//	}
	public Character getCharacter() {
		return character;
	}
	public void setCharacter(Character character) {
		this.character = character;
	}
	public Item getItem() {
		return item;
	}
	public void setItem(Item item) {
		this.item = item;
	}
	public BodySlot getBodySlot() {
		return bodySlot;
	}
	public void setBodySlot(BodySlot bodySlot) {
		this.bodySlot = bodySlot;
	}
	
	
}
