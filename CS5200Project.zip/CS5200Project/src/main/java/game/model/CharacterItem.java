package game.model;


public class CharacterItem {
	protected Character character;
	protected int slotID;
	protected Item item;
	protected int quantity;
	
	public CharacterItem(Character character, int slotID, Item item, int quantity) {
		this.character = character;
		this.slotID = slotID;
		this.item = item;
		this.quantity = quantity;
	}
	
	public CharacterItem(Character character, Item item, int quantity) {
		this.character = character;
		this.item = item;
		this.quantity = quantity;
	}

	public CharacterItem(int slotID) {
		this.slotID = slotID;
	}

	public Character getCharacter() {
		return character;
	}

	public void setCharacter(Character character) {
		this.character = character;
	}

	public int getSlotID() {
		return slotID;
	}

	public void setSlotID(int slotID) {
		this.slotID = slotID;
	}

	public Item getItem() {
		return item;
	}

	public void setItem(Item item) {
		this.item = item;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	
}
