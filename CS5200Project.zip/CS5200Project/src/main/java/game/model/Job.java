package game.model;


public class Job {
	protected int jobID;
	protected String name;
	protected String description;
	
	public Job(int jobID, String name, String description) {
		this.jobID = jobID;
		this.name = name;
		this.description = description;
	}
	
	public Job(String name, String description) {
		this.name = name;
		this.description = description;
	}

	public Job(int jobID) {
		this.jobID = jobID;
	}

	public int getJobID() {
		return jobID;
	}

	public void setJobID(int jobID) {
		this.jobID = jobID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	
	
	
}
