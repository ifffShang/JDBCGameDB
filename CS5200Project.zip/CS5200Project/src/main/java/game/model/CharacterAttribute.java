package game.model;

public class CharacterAttribute {
    public enum Attribute {    	strength,dexterity,vitality,intelligence,mind,criticalHit,determination,directHitRate,defense,magicDefense,attackPower,skillSpeed,attackMagicPotency,healingMagicPotency,spellSpeed,averageItemLevel,tenacity,piety
    }
	protected Character character;
    protected Attribute attribute;
	protected int value;
	public CharacterAttribute(Character character, Attribute attribute, int value) {
		this.character = character;
		this.attribute = attribute;
		this.value = value;
	}
	public Character getCharacter() {
		return character;
	}
	public void setCharacter(Character character) {
		this.character = character;
	}
	public Attribute getAttribute() {
		return attribute;
	}
	public void setAttribute(Attribute attribute) {
		this.attribute = attribute;
	}
	public int getValue() {
		return value;
	}
	public void setValue(int value) {
		this.value = value;
	}

	
}
