package game.model;

public class ConsumableBonus {
    public enum Attribute {    	strength,dexterity,vitality,intelligence,mind,criticalHit,determination,directHitRate,defense,magicDefense,attackPower,skillSpeed,attackMagicPotency,healingMagicPotency,spellSpeed,averageItemLevel,tenacity,piety
    }
    protected Consumable consumable;
    protected Attribute attribute;
    protected int bonus;
    protected int cap;
	public ConsumableBonus(Consumable consumable, Attribute attribute, int bonus, int cap) {
		this.consumable = consumable;
		this.attribute = attribute;
		this.bonus = bonus;
		this.cap = cap;
	}
	public Consumable getConsumable() {
		return consumable;
	}
	public void setConsumable(Consumable consumable) {
		this.consumable = consumable;
	}
	public Attribute getAttribute() {
		return attribute;
	}
	public void setAttribute(Attribute attribute) {
		this.attribute = attribute;
	}
	public int getBonus() {
		return bonus;
	}
	public void setBonus(int bonus) {
		this.bonus = bonus;
	}
	public int getCap() {
		return cap;
	}
	public void setCap(int cap) {
		this.cap = cap;
	}

    
    
}
