package game.model;

public class GearBonus {
    public enum Attribute {    	strength,dexterity,vitality,intelligence,mind,criticalHit,determination,directHitRate,defense,magicDefense,attackPower,skillSpeed,attackMagicPotency,healingMagicPotency,spellSpeed,averageItemLevel,tenacity,piety
    }
    protected Gear gear;
    protected Attribute attribute;
    protected int bonus;
	public GearBonus(Gear gear, Attribute attribute, int bonus) {
		this.gear = gear;
		this.attribute = attribute;
		this.bonus = bonus;
	}
	public Gear getGear() {
		return gear;
	}
	public void setGear(Gear gear) {
		this.gear = gear;
	}
	public Attribute getAttribute() {
		return attribute;
	}
	public void setAttribute(Attribute attribute) {
		this.attribute = attribute;
	}
	public int getBonus() {
		return bonus;
	}
	public void setBonus(int bonus) {
		this.bonus = bonus;
	}

    
}
