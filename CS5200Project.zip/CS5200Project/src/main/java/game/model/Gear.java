package game.model;


public class Gear extends Item{
	public enum BodySlot {
		head, body, hand, legs, feet, off_hand, earring, wrist, ring
	}
	protected int defenseRating;
	protected int magicDefensingRating;
	protected int requiredLevel;
	protected BodySlot bodySlot;
	
	public Gear(int itemID, String name, int maxStackSize, double price, int itemLevel , BodySlot bodySlot, int defenseRating, int magicDefensingRating, int requiredLevel) {
		super(itemID, name, maxStackSize, price, itemLevel);
		this.defenseRating = defenseRating;
		this.magicDefensingRating = magicDefensingRating;
		this.requiredLevel = requiredLevel;
		this.bodySlot = bodySlot;
	}


	public Gear(String name, int maxStackSize, double price, int itemLevel , BodySlot bodySlot, int defenseRating, int magicDefensingRating,
			int requiredLevel) {
		super(name, maxStackSize, price, itemLevel);
		this.defenseRating = defenseRating;
		this.magicDefensingRating = magicDefensingRating;
		this.requiredLevel = requiredLevel;
		this.bodySlot = bodySlot;
	}
	

	public Gear(int itemID) {
		super(itemID);
	}


	public int getDefenseRating() {
		return defenseRating;
	}


	public void setDefenseRating(int defenseRating) {
		this.defenseRating = defenseRating;
	}


	public int getMagicDefenseRating() {
		return magicDefensingRating;
	}


	public void setMagicDefensingRating(int magicDefensingRating) {
		this.magicDefensingRating = magicDefensingRating;
	}


	public int getRequiredLevel() {
		return requiredLevel;
	}


	public void setRequiredLevel(int requiredLevel) {
		this.requiredLevel = requiredLevel;
	}


	public BodySlot getBodySlot() {
		return bodySlot;
	}


	public void setBodySlot(BodySlot bodySlot) {
		this.bodySlot = bodySlot;
	}

	


	
}
