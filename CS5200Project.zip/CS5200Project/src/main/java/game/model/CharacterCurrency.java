package game.model;

public class CharacterCurrency {
	protected Currency currency;
	protected Character character;
	protected int ownedAmount;
	protected int weeklyOwnedAmount;
	
	
	public CharacterCurrency(Currency currency, Character character, int ownedAmount,
			int weeklyOwnedAmount) {
		this.currency = currency;
		this.character = character;
		this.ownedAmount = ownedAmount;
		this.weeklyOwnedAmount = weeklyOwnedAmount;
	}
	
	public CharacterCurrency(int ownedAmount,
			int weeklyOwnedAmount) {
		this.ownedAmount = ownedAmount;
		this.weeklyOwnedAmount = weeklyOwnedAmount;
	}

	public CharacterCurrency(Currency currency, Character character) {
		this.currency = currency;
		this.character = character;
	}

	public Currency getCurrency() {
		return currency;
	}

	public void setCurrency(Currency currency) {
		this.currency = currency;
	}

	public Character getCharacter() {
		return character;
	}

	public void setCharacter(Character character) {
		this.character = character;
	}

	public int getOwnedAmount() {
		return ownedAmount;
	}

	public void setOwnedAmount(int ownedAmount) {
		this.ownedAmount = ownedAmount;
	}

	public int getWeeklyOwnedAmount() {
		return weeklyOwnedAmount;
	}

	public void setWeeklyOwnedAmount(int weeklyOwnedAmount) {
		this.weeklyOwnedAmount = weeklyOwnedAmount;
	}
	
	
	
	
}
