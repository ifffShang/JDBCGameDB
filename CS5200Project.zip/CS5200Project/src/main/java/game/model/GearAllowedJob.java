package game.model;


public class GearAllowedJob {
	protected Job job;
	protected Gear gear;
	
	public GearAllowedJob(Job job, Gear gear) {
		this.job = job;
		this.gear = gear;
	}


	public GearAllowedJob() {
	}


	public Job getJob() {
		return job;
	}


	public void setjob(Job job) {
		this.job = job;
	}


	public Gear getGear() {
		return gear;
	}


	public void setGear(Gear gear) {
		this.gear = gear;
	}
	
	
}
