package game.model;


public class Currency {
	protected int currencyID;
	protected String name;
	protected String description;
	protected int cap;
	protected int weeklyCap;
    
	public Currency(int currencyID, String name, String description, int cap, int weeklyCap) {
		this.currencyID = currencyID;
		this.name = name;
		this.description = description;
		this.cap = cap;
		this.weeklyCap = weeklyCap;
	}
	
	public Currency(String name, String description, int cap, int weeklyCap) {
		this.name = name;
		this.description = description;
		this.cap = cap;
		this.weeklyCap = weeklyCap;
	}

	public Currency(int currencyID) {
		this.currencyID = currencyID;
	}

	public int getCurrencyID() {
		return currencyID;
	}

	public void setCurrencyID(int currencyID) {
		this.currencyID = currencyID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getCap() {
		return cap;
	}

	public void setCap(int cap) {
		this.cap = cap;
	}

	public int getWeeklyCap() {
		return weeklyCap;
	}

	public void setWeeklyCap(int weeklyCap) {
		this.weeklyCap = weeklyCap;
	}
    
	
	
    
}
