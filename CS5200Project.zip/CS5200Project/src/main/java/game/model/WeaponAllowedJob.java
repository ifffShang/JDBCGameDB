package game.model;

public class WeaponAllowedJob {
	protected Job job;
	protected Weapon weapon;
	
	public WeaponAllowedJob(Job job, Weapon weapon) {
		this.job = job;
		this.weapon = weapon;
	}
	
	public WeaponAllowedJob() {
	}
	
	public Job getjob() {
		return job;
	}
	
	public void setjob(Job job) {
		this.job = job;
	}
	
	public Weapon getWeapon() {
		return weapon;
	}
	
	public void setWeapon(Weapon weapon) {
		this.weapon = weapon;
	}
	
}
