package game.model;


public class Player {
	protected int playerID;
	protected String username;
	protected String emailAddress;

    public Player(int playerID, String username, String emailAddress) {
        this.playerID = playerID;
        this.username = username;
        this.emailAddress = emailAddress;
    }

    public Player(String username, String emailAddress) {
        this.username = username;
        this.emailAddress = emailAddress;
    }
    
    public Player(int playerID) {
		this.playerID = playerID;
	}

	public int getPlayerID() {
        return playerID;
    }

    public void setPlayerID(int playerID) {
        this.playerID = playerID;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }
}

