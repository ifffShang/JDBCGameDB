package game.model;

public class WeaponBonus {
    public enum Attribute {    	strength,dexterity,vitality,intelligence,mind,criticalHit,determination,directHitRate,defense,magicDefense,attackPower,skillSpeed,attackMagicPotency,healingMagicPotency,spellSpeed,averageItemLevel,tenacity,piety
    }
    protected Weapon weapon;
    protected Attribute attribute;
    protected int bonus;
	public WeaponBonus(Weapon weapon, Attribute attribute, int bonus) {
		this.weapon = weapon;
		this.attribute = attribute;
		this.bonus = bonus;
	}
	public Weapon getWeapon() {
		return weapon;
	}
	public void setWeapon(Weapon weapon) {
		this.weapon = weapon;
	}
	public Attribute getAttribute() {
		return attribute;
	}
	public void setAttribute(Attribute attribute) {
		this.attribute = attribute;
	}
	public int getBonus() {
		return bonus;
	}
	public void setBonus(int bonus) {
		this.bonus = bonus;
	}

}
