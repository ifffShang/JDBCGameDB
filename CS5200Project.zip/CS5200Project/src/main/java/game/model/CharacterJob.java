package game.model;


public class CharacterJob {
	protected Character character;
	protected Job job;
	protected int level;
	
	
	public CharacterJob(Character character, Job job, int level) {
		this.character = character;
		this.job = job;
		this.level = 1;
	}
	public CharacterJob(Character character, Job job) {
		this.character = character;
		this.job = job;
	}
	public CharacterJob(int level) {
		this.level = 1;
	}
	public Character getCharacter() {
		return character;
	}
	public void setCharacter(Character character) {
		this.character = character;
	}
	public Job getjob() {
		return job;
	}
	public void setjob(Job job) {
		this.job = job;
	}
	public int getLevel() {
		return level;
	}
	public void setLevel(int level) {
		this.level = level;
	}
	
	
}
