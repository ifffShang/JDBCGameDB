package game.servlet;

import game.dal.*;
import game.model.*;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.annotation.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/weaponlist")
public class WeaponListServlet extends HttpServlet {

  protected WeaponDao weaponDao;

  @Override
  public void init() throws ServletException {
    weaponDao = WeaponDao.getInstance();
  }

  @Override
  public void doGet(HttpServletRequest req, HttpServletResponse resp)
          throws ServletException, IOException {
    Map<String, String> messages = new HashMap<String, String>();
    req.setAttribute("messages", messages);

    List<Weapon> weapons = new ArrayList<Weapon>();

    String itemLevel = req.getParameter("itemLevel");
    if (itemLevel == null || itemLevel.trim().isEmpty()) {
      messages.put("success", "Please enter a valid itemLevel.");
    } else {
      try {
        weapons = weaponDao.getWeaponsListByItemLevel(Integer.parseInt(itemLevel));
      } catch (SQLException e) {
        e.printStackTrace();
        throw new IOException(e);
      }
      messages.put("success", "Displaying results for itemLevel " + itemLevel);
    }
    req.setAttribute("weapons", weapons);

    req.getRequestDispatcher("/WeaponList.jsp").forward(req, resp);
  }

  @Override
  public void doPost(HttpServletRequest req, HttpServletResponse resp)
          throws ServletException, IOException {
    Map<String, String> messages = new HashMap<String, String>();
    req.setAttribute("messages", messages);

    List<Weapon> weapons = new ArrayList<Weapon>();

    String itemLevel = req.getParameter("itemLevel");
    if (itemLevel == null || itemLevel.trim().isEmpty()) {
      messages.put("success", "Please enter a valid itemLevel.");
    } else {
      try {
        weapons = weaponDao.getWeaponsListByItemLevel(Integer.parseInt(itemLevel));
      } catch (SQLException e) {
        e.printStackTrace();
        throw new IOException(e);
      }
      messages.put("success", "Displaying results for itemLevel " + itemLevel);
    }
    req.setAttribute("weapons", weapons);

    req.getRequestDispatcher("/WeaponList.jsp").forward(req, resp);
  }
}