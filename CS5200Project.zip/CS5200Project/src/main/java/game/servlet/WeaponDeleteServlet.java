package game.servlet;

import game.dal.*;
import game.model.*;

import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.annotation.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/weapondelete")
public class WeaponDeleteServlet extends HttpServlet {

  protected WeaponDao weaponDao;

  @Override
  public void init() throws ServletException {
    weaponDao = WeaponDao.getInstance();
  }

  @Override
  public void doGet(HttpServletRequest req, HttpServletResponse resp)
          throws ServletException, IOException {
    Map<String, String> messages = new HashMap<String, String>();
    req.setAttribute("messages", messages);
    messages.put("title", "Delete Weapon");
    req.getRequestDispatcher("/WeaponDelete.jsp").forward(req, resp);
  }

  @Override
  public void doPost(HttpServletRequest req, HttpServletResponse resp)
          throws ServletException, IOException {
    Map<String, String> messages = new HashMap<String, String>();
    req.setAttribute("messages", messages);

    // Retrieve weapon ID from request.
    String weaponId = req.getParameter("weaponId");
    if (weaponId == null || weaponId.trim().isEmpty()) {
      messages.put("title", "Invalid WeaponID");
      messages.put("disableSubmit", "true");
    } else {
      try {
        Weapon weapon = new Weapon(Integer.parseInt(weaponId));
        weaponDao.deleteWeapon(weapon);
        messages.put("title", "Successfully deleted " + weaponId);
        messages.put("disableSubmit", "true");
      } catch (IllegalArgumentException e) {
        messages.put("title", "You are not allowed to delete `Weapon1`");
        messages.put("disableSubmit", "false");
      } catch (SQLException e) {
        e.printStackTrace();
        throw new IOException(e);
      }
    }

    req.getRequestDispatcher("/WeaponDelete.jsp").forward(req, resp);
  }
}