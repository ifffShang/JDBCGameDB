package game.servlet;

import game.dal.WeaponDao;
import game.model.Weapon;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@WebServlet("/findweapons")
public class FindWeapons extends HttpServlet {

  protected WeaponDao weaponDao;

  @Override
  public void init() throws ServletException {
    weaponDao = WeaponDao.getInstance();
  }

  private static final Comparator<Weapon> WEAPON_NAME_COMPARATOR = (w1, w2) -> {
    String name1 = w1.getName();
    String name2 = w2.getName();
    
    String numPart1 = extractNumberPart(name1);
    String numPart2 = extractNumberPart(name2);
    
    int result = numPart1.compareTo(numPart2);

    if (result == 0) {
      result = name1.compareTo(name2);
    }

    return result;
  };

  private static String extractNumberPart(String name) {
    StringBuilder numPart = new StringBuilder();
    int index = name.length() - 1;

    while (index >= 0 && Character.isDigit(name.charAt(index))) {
      numPart.insert(0, name.charAt(index));
      index--;
    }

    while (numPart.length() < 10) {
      numPart.insert(0, "0");
    }

    return numPart.toString();
  }

  @Override
  public void doGet(HttpServletRequest req, HttpServletResponse resp)
          throws ServletException, IOException {
    Map<String, String> messages = new HashMap<String, String>();
    req.setAttribute("messages", messages);

    List<Weapon> weapons = new ArrayList<Weapon>();

    String name = req.getParameter("name");
    String sortKey = req.getParameter("sortKey");
    if (name == null || name.trim().isEmpty()) {
      messages.put("success", "Please enter a valid name.");
    } else {
      try {
        weapons = weaponDao.getWeaponsByName(name);

        if (sortKey != null && !sortKey.isEmpty()) {
          switch (sortKey) {
            case "name":
              weapons.sort(WEAPON_NAME_COMPARATOR);
              break;
            case "itemLevel":
              weapons.sort(Comparator.comparingInt(Weapon::getItemLevel));
              break;
            case "physicalDamage":
              weapons.sort(Comparator.comparingInt(Weapon::getPhysicalDamage));
              break;
            case "magicDamage":
              weapons.sort(Comparator.comparingInt(Weapon::getMagicDamage));
              break;
            default:
              messages.put("success", "Invalid sort key. Displaying results without sorting.");
          }
        }
      } catch (SQLException e) {
        e.printStackTrace();
        throw new IOException(e);
      }
      messages.put("success", "Displaying results for " + name);
    }
    req.setAttribute("weapons", weapons);

    req.getRequestDispatcher("/FindWeapons.jsp").forward(req, resp);
  }

  @Override
  public void doPost(HttpServletRequest req, HttpServletResponse resp)
          throws ServletException, IOException {
    Map<String, String> messages = new HashMap<String, String>();
    req.setAttribute("messages", messages);

    List<Weapon> weapons = new ArrayList<Weapon>();

    String name = req.getParameter("name");
    String sortKey = req.getParameter("sortKey");
    if (name == null || name.trim().isEmpty()) {
      messages.put("success", "Please enter a valid name.");
    } else {
      try {
        weapons = weaponDao.getWeaponsByName(name);

        if (sortKey != null && !sortKey.isEmpty()) {
          switch (sortKey) {
            case "name":
              weapons.sort(WEAPON_NAME_COMPARATOR);
              break;
            case "itemLevel":
              weapons.sort(Comparator.comparingInt(Weapon::getItemLevel));
              break;
            case "physicalDamage":
              weapons.sort(Comparator.comparingInt(Weapon::getPhysicalDamage));
              break;
            case "magicDamage":
              weapons.sort(Comparator.comparingInt(Weapon::getMagicDamage));
              break;
            default:
              messages.put("success", "Invalid sort key. Displaying results without sorting.");
          }
        }
      } catch (SQLException e) {
        e.printStackTrace();
        throw new IOException(e);
      }
      messages.put("success", "Displaying results for " + name);
    }
    req.setAttribute("weapons", weapons);

    req.getRequestDispatcher("/FindWeapons.jsp").forward(req, resp);
  }
}