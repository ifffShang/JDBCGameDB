package game.servlet;

import game.dal.*;
import game.model.*;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.annotation.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/weapondetail")
public class WeaponDetailServlet extends HttpServlet {

  protected WeaponDao weaponDao;
  protected WeaponBonusDao weaponBonusDao;
  protected WeaponAllowedJobDao weaponAllowedJobDao;

  @Override
  public void init() throws ServletException {
    weaponDao = WeaponDao.getInstance();
    weaponBonusDao = WeaponBonusDao.getInstance();
    weaponAllowedJobDao = WeaponAllowedJobDao.getInstance();
  }

  @Override
  public void doGet(HttpServletRequest req, HttpServletResponse resp)
          throws ServletException, IOException {
    Map<String, String> messages = new HashMap<String, String>();
    req.setAttribute("messages", messages);

    String weaponId = req.getParameter("weaponId");

    Weapon weapon = null;
    try {
      weapon = weaponDao.getWeaponByItemID(Integer.parseInt(weaponId));
      if (weapon == null) {
        messages.put("success", "Weapon does not exist.");
      }
    } catch (SQLException e) {
      e.printStackTrace();
      throw new IOException(e);
    }

    WeaponBonus weaponBonus = null;
    try {
      weaponBonus = weaponBonusDao.getWeaponBonusByWeaponIDAndAttribute(Integer.parseInt(weaponId), WeaponBonus.Attribute.attackPower);
    } catch (SQLException e) {
      e.printStackTrace();
      throw new IOException(e);
    }

    List<WeaponAllowedJob> allowedJobs = new ArrayList<>();
    try {
      JobDao jobDao = JobDao.getInstance();
      List<Job> jobs = jobDao.getAllJobs();
      for (Job job : jobs) {
        WeaponAllowedJob allowedJob = weaponAllowedJobDao.getWeaponAllowedJobByID(job.getJobID(), Integer.parseInt(weaponId));
        if (allowedJob != null) {
          allowedJobs.add(allowedJob);
        }
      }
    } catch (SQLException e) {
      e.printStackTrace();
      throw new IOException(e);
    }

    req.setAttribute("weapon", weapon);
    req.setAttribute("weaponBonus", weaponBonus);
    req.setAttribute("allowedJobs", allowedJobs);

    req.getRequestDispatcher("/WeaponDetail.jsp").forward(req, resp);
  }
}