package game.servlet;

import game.dal.*;
import game.model.*;

import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.annotation.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/weaponcreate")
public class WeaponCreateServlet extends HttpServlet {

  protected WeaponDao weaponDao;

  @Override
  public void init() throws ServletException {
    weaponDao = WeaponDao.getInstance();
  }

  @Override
  public void doGet(HttpServletRequest req, HttpServletResponse resp)
          throws ServletException, IOException {
    Map<String, String> messages = new HashMap<String, String>();
    req.setAttribute("messages", messages);

    req.getRequestDispatcher("/WeaponCreate.jsp").forward(req, resp);
  }

  @Override
  public void doPost(HttpServletRequest req, HttpServletResponse resp)
          throws ServletException, IOException {
    Map<String, String> messages = new HashMap<String, String>();
    req.setAttribute("messages", messages);

    String name = req.getParameter("name");
    int maxStackSize = Integer.parseInt(req.getParameter("maxStackSize"));
    double price = Double.parseDouble(req.getParameter("price"));
    int itemLevel = Integer.parseInt(req.getParameter("itemLevel"));
    int physicalDamage = Integer.parseInt(req.getParameter("physicalDamage"));
    int magicDamage = Integer.parseInt(req.getParameter("magicDamage"));
    int autoAttack = Integer.parseInt(req.getParameter("autoAttack"));
    int delay = Integer.parseInt(req.getParameter("delay"));
    int requiredLevel = Integer.parseInt(req.getParameter("requiredLevel"));

    try {
      Weapon weapon = new Weapon(name, maxStackSize, price, itemLevel, physicalDamage, magicDamage, autoAttack, delay, requiredLevel);
      weapon = weaponDao.create(weapon);
      messages.put("success", "Successfully created " + weapon.getName());
    } catch (SQLException e) {
      e.printStackTrace();
      throw new IOException(e);
    }

    req.getRequestDispatcher("/WeaponCreate.jsp").forward(req, resp);
  }
}