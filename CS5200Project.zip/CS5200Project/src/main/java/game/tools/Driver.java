//package game.tools;
//
//import java.sql.SQLException;
//import java.util.List;
//
//import game.dal.CharacterAttributeDao;
//import game.dal.CharacterCurrencyDao;
//import game.dal.CharacterDao;
//import game.dal.CharacterItemDao;
//import game.dal.CharacterJobDao;
//import game.dal.ConsumableBonusDao;
//import game.dal.ConsumableDao;
//import game.dal.CurrencyDao;
//import game.dal.EquipedGearDao;
//import game.dal.GearAllowedJobDao;
//import game.dal.GearBonusDao;
//import game.dal.GearDao;
//import game.dal.ItemDao;
//import game.dal.JobDao;
//import game.dal.PlayerDao;
//import game.dal.WeaponAllowedJobDao;
//import game.dal.WeaponBonusDao;
//import game.dal.WeaponDao;
//import game.model.Consumable;
//import game.model.ConsumableBonus;
//import game.model.Currency;
//import game.model.EquipedGear;
//import game.model.Gear;
//import game.model.GearAllowedJob;
//import game.model.GearBonus;
//import game.model.Item;
//import game.model.Job;
//import game.model.Player;
//import game.model.Weapon;
//import game.model.WeaponAllowedJob;
//import game.model.WeaponBonus;
//import game.model.CharacterJob;
//import game.model.Character;
//import game.model.CharacterAttribute;
//import game.model.CharacterCurrency;
//import game.model.CharacterItem;
//
//public class Driver {
//	public static void main (String[] args) throws SQLException{
//		
//		// DAO instances
//		ItemDao itemDao = ItemDao.getInstance();
//		GearDao gearDao = GearDao.getInstance();
//		WeaponDao weaponDao = WeaponDao.getInstance();
//		ConsumableDao consumableDao = ConsumableDao.getInstance();
//		PlayerDao playerDao = PlayerDao.getInstance();
//		CharacterDao characterDao = CharacterDao.getInstance();
//		CurrencyDao currencyDao = CurrencyDao.getInstance();
//		CharacterCurrencyDao characterCurrencyDao = CharacterCurrencyDao.getInstance();
//		EquipedGearDao equipedGearDao = EquipedGearDao.getInstance();
//		CharacterItemDao characterItemDao = CharacterItemDao.getInstance();
//		JobDao jobDao = JobDao.getInstance();
//		CharacterJobDao characterJobDao = CharacterJobDao.getInstance();
//		GearAllowedJobDao gearAllowedJobDao = GearAllowedJobDao.getInstance();
//		WeaponAllowedJobDao weaponAllowedJobDao = WeaponAllowedJobDao.getInstance();
//		CharacterAttributeDao characterAttributeDao = CharacterAttributeDao.getInstance();
//		GearBonusDao gearBonusDao = GearBonusDao.getInstance();
//		WeaponBonusDao weaponBonusDao = WeaponBonusDao.getInstance();
//		ConsumableBonusDao consumableBonusDao = ConsumableBonusDao.getInstance();
//		
//		// Create methods for Weapon
//		Weapon weapon1 = new Weapon("Weapon1", 1, 100.0, 1, 10, 5, 1, 1000, 1);
//		weapon1 = weaponDao.create(weapon1);
//
//		Weapon weapon2 = new Weapon("Weapon2", 1, 200.0, 2, 20, 10, 2, 1500, 2);
//		weapon2 = weaponDao.create(weapon2);
//
//		Weapon weapon3 = new Weapon("Weapon3", 1, 300.0, 3, 30, 15, 3, 2000, 3);
//		weapon3 = weaponDao.create(weapon3);
//		
//		Weapon weapon4 = new Weapon("Weapon4", 1, 400.0, 4, 40, 20, 4, 2500, 4);
//		weapon4 = weaponDao.create(weapon4);
//
//		Weapon weapon5 = new Weapon("Weapon5", 1, 500.0, 5, 50, 25, 5, 3000, 5);
//		weapon5 = weaponDao.create(weapon5);
//
//		Weapon weapon6 = new Weapon("Weapon6", 1, 600.0, 6, 60, 30, 6, 3500, 6);
//		weapon6 = weaponDao.create(weapon6);
//
//		Weapon weapon7 = new Weapon("Weapon7", 1, 700.0, 7, 70, 35, 7, 4000, 7);
//		weapon7 = weaponDao.create(weapon7);
//
//		Weapon weapon8 = new Weapon("Weapon8", 1, 800.0, 8, 80, 40, 8, 4500, 8);
//		weapon8 = weaponDao.create(weapon8);
//
//		Weapon weapon9 = new Weapon("Weapon9", 1, 900.0, 9, 90, 45, 9, 5000, 9);
//		weapon9 = weaponDao.create(weapon9);
//
//		Weapon weapon10 = new Weapon("Weapon10", 1, 1000.0, 10, 100, 50, 10, 5500, 10);
//		weapon10 = weaponDao.create(weapon10);
//		
//		// Create methods for Item
//		Item item1 = new Item("Item1", 10, 100.0, 1);
//		item1 = itemDao.create(item1);
//
//		Item item2 = new Item("Item2", 20, 200.0, 2);
//		item2 = itemDao.create(item2);
//
//		Item item3 = new Item("Item3", 30, 300.0, 3);
//		item3 = itemDao.create(item3);
//		
//		Item item4 = new Item("Item4", 40, 400.0, 4);
//		item4 = itemDao.create(item4);
//
//		Item item5 = new Item("Item5", 50, 500.0, 5);
//		item5 = itemDao.create(item5);
//
//		Item item6 = new Item("Item6", 60, 600.0, 6);
//		item6 = itemDao.create(item6);
//
//		Item item7 = new Item("Item7", 70, 700.0, 7);
//		item7 = itemDao.create(item7);
//
//		Item item8 = new Item("Item8", 80, 800.0, 8);
//		item8 = itemDao.create(item8);
//
//		Item item9 = new Item("Item9", 90, 900.0, 9);
//		item9 = itemDao.create(item9);
//
//		Item item10 = new Item("Item10", 100, 1000.0, 10);
//		item10 = itemDao.create(item10);
//
//		// Create methods for Gear
//		Gear gear1 = new Gear("Gear1", 1, 100.0, 1, Gear.BodySlot.head, 10, 5, 1);
//		gear1 = gearDao.create(gear1);
//
//		Gear gear2 = new Gear("Gear2", 1, 200.0, 2, Gear.BodySlot.body, 20, 10, 2);
//		gear2 = gearDao.create(gear2);
//
//		Gear gear3 = new Gear("Gear3", 1, 300.0, 3, Gear.BodySlot.legs, 30, 15, 3);
//		gear3 = gearDao.create(gear3);
//
//		Gear gear4 = new Gear("Gear4", 1, 400.0, 4, Gear.BodySlot.head, 40, 20, 4);
//		gear4 = gearDao.create(gear4);
//
//		Gear gear5 = new Gear("Gear5", 1, 500.0, 5, Gear.BodySlot.body, 50, 25, 5);
//		gear5 = gearDao.create(gear5);
//
//		Gear gear6 = new Gear("Gear6", 1, 600.0, 6, Gear.BodySlot.legs, 60, 30, 6);
//		gear6 = gearDao.create(gear6);
//
//		Gear gear7 = new Gear("Gear7", 1, 700.0, 7, Gear.BodySlot.feet, 70, 35, 7);
//		gear7 = gearDao.create(gear7);
//
//		Gear gear8 = new Gear("Gear8", 1, 800.0, 8, Gear.BodySlot.hand, 80, 40, 8);
//		gear8 = gearDao.create(gear8);
//
//		Gear gear9 = new Gear("Gear9", 1, 900.0, 9, Gear.BodySlot.head, 90, 45, 9);
//		gear9 = gearDao.create(gear9);
//
//		Gear gear10 = new Gear("Gear10", 1, 1000.0, 10, Gear.BodySlot.body, 100, 50, 10);
//		gear10 = gearDao.create(gear10);
//		
//		// Create methods for Consumable
//		Consumable consumable1 = new Consumable("Consumable1", 10, 50.0, 1, "Description for Consumable1");
//		consumable1 = consumableDao.create(consumable1);
//
//		Consumable consumable2 = new Consumable("Consumable2", 5, 100.0, 2, "Description for Consumable2");
//		consumable2 = consumableDao.create(consumable2);
//
//		Consumable consumable3 = new Consumable("Consumable3", 3, 150.0, 3, "Description for Consumable3");
//		consumable3 = consumableDao.create(consumable3);
//
//		Consumable consumable4 = new Consumable("Consumable4", 7, 200.0, 4, "Description for Consumable4");
//		consumable4 = consumableDao.create(consumable4);
//		
//		Consumable consumable5 = new Consumable("Consumable5", 8, 250.0, 5, "Description for Consumable5");
//		consumable5 = consumableDao.create(consumable5);
//		
//		Consumable consumable6 = new Consumable("Consumable6", 9, 300.0, 6, "Description for Consumable6");
//		consumable6 = consumableDao.create(consumable6);
//		
//		Consumable consumable7 = new Consumable("Consumable7", 6, 350.0, 7, "Description for Consumable7");
//		consumable7 = consumableDao.create(consumable7);
//		
//		Consumable consumable8 = new Consumable("Consumable8", 5, 400.0, 8, "Description for Consumable8");
//		consumable8 = consumableDao.create(consumable8);
//		
//		Consumable consumable9 = new Consumable("Consumable9", 4, 450.0, 9, "Description for Consumable9");
//		consumable9 = consumableDao.create(consumable9);
//		
//		Consumable consumable10 = new Consumable("Consumable10", 10, 500.0, 10, "Description for Consumable10");
//		consumable10 = consumableDao.create(consumable10);
//
//		// Create methods for Player
//		Player player1 = new Player("player1", "player1@example.com");
//		player1 = playerDao.create(player1);
//
//		Player player2 = new Player("player2", "player2@example.com");
//		player2 = playerDao.create(player2);
//
//		Player player3 = new Player("player3", "player3@example.com");
//		player3 = playerDao.create(player3);
//
//		Player player4 = new Player("player4", "player4@example.com");
//		player4 = playerDao.create(player4);
//		
//		Player player5 = new Player("player5", "player5@example.com");
//		player5 = playerDao.create(player5);
//		
//		Player player6 = new Player("player6", "player6@example.com");
//		player6 = playerDao.create(player6);
//		
//		Player player7 = new Player("player7", "player7@example.com");
//		player7 = playerDao.create(player7);
//		
//		Player player8 = new Player("player8", "player8@example.com");
//		player8 = playerDao.create(player8);
//		
//		Player player9 = new Player("player9", "player9@example.com");
//		player9 = playerDao.create(player9);
//		
//		Player player10 = new Player("player10", "player10@example.com");
//		player10 = playerDao.create(player10);
//
//		// Create methods for Character
//		Character character1 = new Character(player1, "firstName1", "lastName1", weapon1);
//		character1 = characterDao.create(character1);
//
//		Character character2 = new Character(player2, "firstName2", "lastName2", weapon2);
//		character2 = characterDao.create(character2);
//
//		Character character3 = new Character(player3, "firstName3", "lastName3", weapon3);
//		character3 = characterDao.create(character3);
//		
//		Character character4 = new Character(player4, "firstName4", "lastName4", weapon4);
//		character4 = characterDao.create(character4);
//		
//		Character character5 = new Character(player5, "firstName5", "lastName5", weapon5);
//		character5 = characterDao.create(character5);
//		
//		Character character6 = new Character(player6, "firstName6", "lastName6", weapon6);
//		character6 = characterDao.create(character6);
//		
//		Character character7 = new Character(player7, "firstName7", "lastName7", weapon7);
//		character7 = characterDao.create(character7);
//		
//		Character character8 = new Character(player8, "firstName8", "lastName8", weapon8);
//		character8 = characterDao.create(character8);
//		
//		Character character9 = new Character(player9, "firstName9", "lastName9", weapon9);
//		character9 = characterDao.create(character9);
//		
//		Character character10 = new Character(player10, "firstName10", "lastName10", weapon10);
//		character10 = characterDao.create(character10);
//
//
//		// Create methods for Currency
//		Currency currency1 = new Currency("Currency1", "Description1", 1000, 500);
//		currency1 = currencyDao.create(currency1);
//
//		Currency currency2 = new Currency("Currency2", "Description2", 2000, 1000);
//		currency2 = currencyDao.create(currency2);
//
//		Currency currency3 = new Currency("Currency3", "Description3", 99999, 99999);
//		currency3 = currencyDao.create(currency3);
//
//		Currency currency4 = new Currency("Currency4", "Description4", 3000, 1500);
//		currency4 = currencyDao.create(currency4);
//		
//		Currency currency5 = new Currency("Currency5", "Description5", 4000, 2000);
//		currency5 = currencyDao.create(currency5);
//		
//		Currency currency6 = new Currency("Currency6", "Description6", 5000, 2500);
//		currency6 = currencyDao.create(currency6);
//		
//		Currency currency7 = new Currency("Currency7", "Description7", 6000, 3000);
//		currency7 = currencyDao.create(currency7);
//		
//		Currency currency8 = new Currency("Currency8", "Description8", 7000, 3500);
//		currency8 = currencyDao.create(currency8);
//		
//		Currency currency9 = new Currency("Currency9", "Description9", 8000, 4000);
//		currency9 = currencyDao.create(currency9);
//		
//		Currency currency10 = new Currency("Currency10", "Description10", 9000, 4500);
//		currency10 = currencyDao.create(currency10);
//
//		// Create methods for CharacterCurrency
//		CharacterCurrency characterCurrency1 = new CharacterCurrency(currency1, character1, 100, 50);
//		characterCurrency1 = characterCurrencyDao.create(characterCurrency1);
//
//		CharacterCurrency characterCurrency2 = new CharacterCurrency(currency2, character2, 200, 100);
//		characterCurrency2 = characterCurrencyDao.create(characterCurrency2);
//
//		CharacterCurrency characterCurrency3 = new CharacterCurrency(currency3, character3, 9999, 999);
//		characterCurrency3 = characterCurrencyDao.create(characterCurrency3);
//		
//		CharacterCurrency characterCurrency4 = new CharacterCurrency(currency4, character4, 300, 150);
//		characterCurrency4 = characterCurrencyDao.create(characterCurrency4);
//		
//		CharacterCurrency characterCurrency5 = new CharacterCurrency(currency5, character5, 400, 200);
//		characterCurrency5 = characterCurrencyDao.create(characterCurrency5);
//		
//		CharacterCurrency characterCurrency6 = new CharacterCurrency(currency6, character6, 500, 250);
//		characterCurrency6 = characterCurrencyDao.create(characterCurrency6);
//		
//		CharacterCurrency characterCurrency7 = new CharacterCurrency(currency7, character7, 600, 300);
//		characterCurrency7 = characterCurrencyDao.create(characterCurrency7);
//		
//		CharacterCurrency characterCurrency8 = new CharacterCurrency(currency8, character8, 700, 350);
//		characterCurrency8 = characterCurrencyDao.create(characterCurrency8);
//		
//		CharacterCurrency characterCurrency9 = new CharacterCurrency(currency9, character9, 800, 400);
//		characterCurrency9 = characterCurrencyDao.create(characterCurrency9);
//		
//		CharacterCurrency characterCurrency10 = new CharacterCurrency(currency10, character10, 900, 450);
//		characterCurrency10 = characterCurrencyDao.create(characterCurrency10);
//
//
//		// Create methods for EquippedGear
//		EquipedGear equipedGear1 = new EquipedGear(character1, EquipedGear.BodySlot.head, gear1);
//		equipedGear1 = equipedGearDao.create(equipedGear1);
//
//		EquipedGear equipedGear2 = new EquipedGear(character2, EquipedGear.BodySlot.body, gear2);
//		equipedGear2 = equipedGearDao.create(equipedGear2);
//
//		EquipedGear equipedGear3 = new EquipedGear(character3, EquipedGear.BodySlot.hand, gear3);
//		equipedGear3 = equipedGearDao.create(equipedGear3);
//
//		EquipedGear equipedGear4 = new EquipedGear(character4, EquipedGear.BodySlot.legs, gear4);
//		equipedGear4 = equipedGearDao.create(equipedGear4);
//
//		EquipedGear equipedGear5 = new EquipedGear(character5, EquipedGear.BodySlot.feet, gear5);
//		equipedGear5 = equipedGearDao.create(equipedGear5);
//
//		EquipedGear equipedGear6 = new EquipedGear(character6, EquipedGear.BodySlot.hand, gear6);
//		equipedGear6 = equipedGearDao.create(equipedGear6);
//
//		EquipedGear equipedGear7 = new EquipedGear(character7, EquipedGear.BodySlot.body, gear7);
//		equipedGear7 = equipedGearDao.create(equipedGear7);
//
//		EquipedGear equipedGear8 = new EquipedGear(character8, EquipedGear.BodySlot.head, gear8);
//		equipedGear8 = equipedGearDao.create(equipedGear8);
//
//		EquipedGear equipedGear9 = new EquipedGear(character9, EquipedGear.BodySlot.head, gear9);
//		equipedGear9 = equipedGearDao.create(equipedGear9);
//
//		EquipedGear equipedGear10 = new EquipedGear(character10, EquipedGear.BodySlot.body, gear10);
//		equipedGear10 = equipedGearDao.create(equipedGear10);
//
//
//		// Create methods for CharacterItem
//		CharacterItem characterItem1 = new CharacterItem(character1, 1, item1, 10);
//		characterItem1 = characterItemDao.create(characterItem1);
//
//		CharacterItem characterItem2 = new CharacterItem(character2, 2, item2, 5);
//		characterItem2 = characterItemDao.create(characterItem2);
//
//		CharacterItem characterItem3 = new CharacterItem(character3, 3, item3, 20);
//		characterItem3 = characterItemDao.create(characterItem3);
//		
//		CharacterItem characterItem4 = new CharacterItem(character4, 4, item4, 8);
//		characterItem4 = characterItemDao.create(characterItem4);
//		
//		CharacterItem characterItem5 = new CharacterItem(character5, 5, item5, 15);
//		characterItem5 = characterItemDao.create(characterItem5);
//		
//		CharacterItem characterItem6 = new CharacterItem(character6, 6, item6, 12);
//		characterItem6 = characterItemDao.create(characterItem6);
//		
//		CharacterItem characterItem7 = new CharacterItem(character7, 7, item7, 14);
//		characterItem7 = characterItemDao.create(characterItem7);
//		
//		CharacterItem characterItem8 = new CharacterItem(character8, 8, item8, 16);
//		characterItem8 = characterItemDao.create(characterItem8);
//		
//		CharacterItem characterItem9 = new CharacterItem(character9, 9, item9, 18);
//		characterItem9 = characterItemDao.create(characterItem9);
//		
//		CharacterItem characterItem10 = new CharacterItem(character10, 10, item10, 20);
//		characterItem10 = characterItemDao.create(characterItem10);
//
//
//		// Create methods for Job
//		Job job1 = new Job("name1", "description1");
//		job1 = jobDao.create(job1);
//
//		Job job2 = new Job("name2", "description2");
//		job2 = jobDao.create(job2);
//
//		Job job3 = new Job("name3", "description3");
//		job3 = jobDao.create(job3);
//		
//		Job job4 = new Job("name4", "description4");
//		job4 = jobDao.create(job4);
//		
//		Job job5 = new Job("name5", "description5");
//		job5 = jobDao.create(job5);
//		
//		Job job6 = new Job("name6", "description6");
//		job6 = jobDao.create(job6);
//		
//		Job job7 = new Job("name7", "description7");
//		job7 = jobDao.create(job7);
//		
//		Job job8 = new Job("name8", "description8");
//		job8 = jobDao.create(job8);
//		
//		Job job9 = new Job("name9", "description9");
//		job9 = jobDao.create(job9);
//		
//		Job job10 = new Job("name10", "description10");
//		job10 = jobDao.create(job10);
//
//
//		// Create methods for CharacterJob
//		CharacterJob characterJob1 = new CharacterJob(character1, job1, 10);
//		characterJob1 = characterJobDao.create(characterJob1);
//
//		CharacterJob characterJob2 = new CharacterJob(character2, job2, 5);
//		characterJob2 = characterJobDao.create(characterJob2);
//
//		CharacterJob characterJob3 = new CharacterJob(character3, job3, 8);
//		characterJob3 = characterJobDao.create(characterJob3);
//		
//		CharacterJob characterJob4 = new CharacterJob(character4, job4, 12);
//		characterJob4 = characterJobDao.create(characterJob4);
//		
//		CharacterJob characterJob5 = new CharacterJob(character5, job5, 14);
//		characterJob5 = characterJobDao.create(characterJob5);
//		
//		CharacterJob characterJob6 = new CharacterJob(character6, job6, 16);
//		characterJob6 = characterJobDao.create(characterJob6);
//		
//		CharacterJob characterJob7 = new CharacterJob(character7, job7, 18);
//		characterJob7 = characterJobDao.create(characterJob7);
//		
//		CharacterJob characterJob8 = new CharacterJob(character8, job8, 20);
//		characterJob8 = characterJobDao.create(characterJob8);
//		
//		CharacterJob characterJob9 = new CharacterJob(character9, job9, 22);
//		characterJob9 = characterJobDao.create(characterJob9);
//		
//		CharacterJob characterJob10 = new CharacterJob(character10, job10, 24);
//		characterJob10 = characterJobDao.create(characterJob10);
//
//
//		// Create methods for GearAllowedJob
//		GearAllowedJob gearAllowedJob1 = new GearAllowedJob(job1, gear1);
//		gearAllowedJob1 = gearAllowedJobDao.create(gearAllowedJob1);
//
//		GearAllowedJob gearAllowedJob2 = new GearAllowedJob(job2, gear2);
//		gearAllowedJob2 = gearAllowedJobDao.create(gearAllowedJob2);
//
//		GearAllowedJob gearAllowedJob3 = new GearAllowedJob(job3, gear3);
//		gearAllowedJob3 = gearAllowedJobDao.create(gearAllowedJob3);
//		
//		GearAllowedJob gearAllowedJob4 = new GearAllowedJob(job4, gear4);
//		gearAllowedJob4 = gearAllowedJobDao.create(gearAllowedJob4);
//		
//		GearAllowedJob gearAllowedJob5 = new GearAllowedJob(job5, gear5);
//		gearAllowedJob5 = gearAllowedJobDao.create(gearAllowedJob5);
//		
//		GearAllowedJob gearAllowedJob6 = new GearAllowedJob(job6, gear6);
//		gearAllowedJob6 = gearAllowedJobDao.create(gearAllowedJob6);
//		
//		GearAllowedJob gearAllowedJob7 = new GearAllowedJob(job7, gear7);
//		gearAllowedJob7 = gearAllowedJobDao.create(gearAllowedJob7);
//		
//		GearAllowedJob gearAllowedJob8 = new GearAllowedJob(job8, gear8);
//		gearAllowedJob8 = gearAllowedJobDao.create(gearAllowedJob8);
//		
//		GearAllowedJob gearAllowedJob9 = new GearAllowedJob(job9, gear9);
//		gearAllowedJob9 = gearAllowedJobDao.create(gearAllowedJob9);
//		
//		GearAllowedJob gearAllowedJob10 = new GearAllowedJob(job10, gear10);
//		gearAllowedJob10 = gearAllowedJobDao.create(gearAllowedJob10);
//
//		
//		
//
//		// Create methods for WeaponAllowedJob
//		WeaponAllowedJob weaponAllowedJob1 = new WeaponAllowedJob(job1, weapon1);
//		weaponAllowedJob1 = weaponAllowedJobDao.create(weaponAllowedJob1);
//
//		WeaponAllowedJob weaponAllowedJob2 = new WeaponAllowedJob(job2, weapon2);
//		weaponAllowedJob2 = weaponAllowedJobDao.create(weaponAllowedJob2);
//
//		WeaponAllowedJob weaponAllowedJob3 = new WeaponAllowedJob(job3, weapon3);
//		weaponAllowedJob3 = weaponAllowedJobDao.create(weaponAllowedJob3);
//
//		WeaponAllowedJob weaponAllowedJob4 = new WeaponAllowedJob(job4, weapon4);
//		weaponAllowedJob4 = weaponAllowedJobDao.create(weaponAllowedJob4);
//		
//		WeaponAllowedJob weaponAllowedJob5 = new WeaponAllowedJob(job5, weapon5);
//		weaponAllowedJob5 = weaponAllowedJobDao.create(weaponAllowedJob5);
//		
//		WeaponAllowedJob weaponAllowedJob6 = new WeaponAllowedJob(job6, weapon6);
//		weaponAllowedJob6 = weaponAllowedJobDao.create(weaponAllowedJob6);
//		
//		WeaponAllowedJob weaponAllowedJob7 = new WeaponAllowedJob(job7, weapon7);
//		weaponAllowedJob7 = weaponAllowedJobDao.create(weaponAllowedJob7);
//		
//		WeaponAllowedJob weaponAllowedJob8 = new WeaponAllowedJob(job8, weapon8);
//		weaponAllowedJob8 = weaponAllowedJobDao.create(weaponAllowedJob8);
//		
//		WeaponAllowedJob weaponAllowedJob9 = new WeaponAllowedJob(job9, weapon9);
//		weaponAllowedJob9 = weaponAllowedJobDao.create(weaponAllowedJob9);
//		
//		WeaponAllowedJob weaponAllowedJob10 = new WeaponAllowedJob(job10, weapon10);
//		weaponAllowedJob10 = weaponAllowedJobDao.create(weaponAllowedJob10);
//
//		// Create methods for CharacterAttribute
//		CharacterAttribute characterAttribute1 = new CharacterAttribute(character1, CharacterAttribute.Attribute.strength, 10);
//		characterAttribute1 = characterAttributeDao.create(characterAttribute1);
//
//		CharacterAttribute characterAttribute2 = new CharacterAttribute(character2, CharacterAttribute.Attribute.dexterity, 8);
//		characterAttribute2 = characterAttributeDao.create(characterAttribute2);
//
//		CharacterAttribute characterAttribute3 = new CharacterAttribute(character3, CharacterAttribute.Attribute.intelligence, 12);
//		characterAttribute3 = characterAttributeDao.create(characterAttribute3);
//
//		CharacterAttribute characterAttribute4 = new CharacterAttribute(character4, CharacterAttribute.Attribute.mind, 11);
//		characterAttribute4 = characterAttributeDao.create(characterAttribute4);
//		
//		CharacterAttribute characterAttribute5 = new CharacterAttribute(character5, CharacterAttribute.Attribute.criticalHit, 13);
//		characterAttribute5 = characterAttributeDao.create(characterAttribute5);
//		
//		CharacterAttribute characterAttribute6 = new CharacterAttribute(character6, CharacterAttribute.Attribute.determination, 15);
//		characterAttribute6 = characterAttributeDao.create(characterAttribute6);
//		
//		CharacterAttribute characterAttribute7 = new CharacterAttribute(character7, CharacterAttribute.Attribute.directHitRate, 17);
//		characterAttribute7 = characterAttributeDao.create(characterAttribute7);
//		
//		CharacterAttribute characterAttribute8 = new CharacterAttribute(character8, CharacterAttribute.Attribute.defense, 19);
//		characterAttribute8 = characterAttributeDao.create(characterAttribute8);
//		
//		CharacterAttribute characterAttribute9 = new CharacterAttribute(character9, CharacterAttribute.Attribute.magicDefense, 21);
//		characterAttribute9 = characterAttributeDao.create(characterAttribute9);
//		
//		CharacterAttribute characterAttribute10 = new CharacterAttribute(character10, CharacterAttribute.Attribute.attackPower, 23);
//		characterAttribute10 = characterAttributeDao.create(characterAttribute10);
//
//		// Create methods for GearBonus
//		GearBonus gearBonus1 = new GearBonus(gear1, GearBonus.Attribute.strength, 5);
//		gearBonus1 = gearBonusDao.create(gearBonus1);
//
//		GearBonus gearBonus2 = new GearBonus(gear2, GearBonus.Attribute.dexterity, 3);
//		gearBonus2 = gearBonusDao.create(gearBonus2);
//
//		GearBonus gearBonus3 = new GearBonus(gear3, GearBonus.Attribute.intelligence, 6);
//		gearBonus3 = gearBonusDao.create(gearBonus3);
//
//		GearBonus gearBonus4 = new GearBonus(gear4, GearBonus.Attribute.strength, 7);
//		gearBonus4 = gearBonusDao.create(gearBonus4);
//		
//		GearBonus gearBonus5 = new GearBonus(gear5, GearBonus.Attribute.dexterity, 9);
//		gearBonus5 = gearBonusDao.create(gearBonus5);
//		
//		GearBonus gearBonus6 = new GearBonus(gear6, GearBonus.Attribute.intelligence, 11);
//		gearBonus6 = gearBonusDao.create(gearBonus6);
//		
//		GearBonus gearBonus7 = new GearBonus(gear7, GearBonus.Attribute.vitality, 13);
//		gearBonus7 = gearBonusDao.create(gearBonus7);
//		
//		GearBonus gearBonus8 = new GearBonus(gear8, GearBonus.Attribute.mind, 15);
//		gearBonus8 = gearBonusDao.create(gearBonus8);
//		
//		GearBonus gearBonus9 = new GearBonus(gear9, GearBonus.Attribute.criticalHit, 17);
//		gearBonus9 = gearBonusDao.create(gearBonus9);
//		
//		GearBonus gearBonus10 = new GearBonus(gear10, GearBonus.Attribute.determination, 19);
//		gearBonus10 = gearBonusDao.create(gearBonus10);
//
//		// Create methods for WeaponBonus
//		WeaponBonus weaponBonus1 = new WeaponBonus(weapon1, WeaponBonus.Attribute.attackPower, 10);
//		weaponBonus1 = weaponBonusDao.create(weaponBonus1);
//
//		WeaponBonus weaponBonus2 = new WeaponBonus(weapon2, WeaponBonus.Attribute.spellSpeed, 5);
//		weaponBonus2 = weaponBonusDao.create(weaponBonus2);
//
//		WeaponBonus weaponBonus3 = new WeaponBonus(weapon3, WeaponBonus.Attribute.criticalHit, 8);
//		weaponBonus3 = weaponBonusDao.create(weaponBonus3);
//
//		WeaponBonus weaponBonus4 = new WeaponBonus(weapon4, WeaponBonus.Attribute.attackPower, 12);
//		weaponBonus4 = weaponBonusDao.create(weaponBonus4);
//		
//		WeaponBonus weaponBonus5 = new WeaponBonus(weapon5, WeaponBonus.Attribute.skillSpeed, 14);
//		weaponBonus5 = weaponBonusDao.create(weaponBonus5);
//		
//		WeaponBonus weaponBonus6 = new WeaponBonus(weapon6, WeaponBonus.Attribute.spellSpeed, 16);
//		weaponBonus6 = weaponBonusDao.create(weaponBonus6);
//		
//		WeaponBonus weaponBonus7 = new WeaponBonus(weapon7, WeaponBonus.Attribute.criticalHit, 18);
//		weaponBonus7 = weaponBonusDao.create(weaponBonus7);
//		
//		WeaponBonus weaponBonus8 = new WeaponBonus(weapon8, WeaponBonus.Attribute.healingMagicPotency, 20);
//		weaponBonus8 = weaponBonusDao.create(weaponBonus8);
//		
//		WeaponBonus weaponBonus9 = new WeaponBonus(weapon9, WeaponBonus.Attribute.attackMagicPotency, 22);
//		weaponBonus9 = weaponBonusDao.create(weaponBonus9);
//		
//		WeaponBonus weaponBonus10 = new WeaponBonus(weapon10, WeaponBonus.Attribute.directHitRate, 24);
//		weaponBonus10 = weaponBonusDao.create(weaponBonus10);
//		// Create methods for ConsumableBonus
//		ConsumableBonus consumableBonus1 = new ConsumableBonus(consumable1, ConsumableBonus.Attribute.vitality, 50, 100);
//		consumableBonus1 = consumableBonusDao.create(consumableBonus1);
//
//		ConsumableBonus consumableBonus2 = new ConsumableBonus(consumable2, ConsumableBonus.Attribute.mind, 30, 80);
//		consumableBonus2 = consumableBonusDao.create(consumableBonus2);
//
//		ConsumableBonus consumableBonus3 = new ConsumableBonus(consumable3, ConsumableBonus.Attribute.determination, 20, 60);
//		consumableBonus3 = consumableBonusDao.create(consumableBonus3);
//
//		ConsumableBonus consumableBonus4 = new ConsumableBonus(consumable4, ConsumableBonus.Attribute.vitality, 60, 120);
//		consumableBonus4 = consumableBonusDao.create(consumableBonus4);
//		
//		ConsumableBonus consumableBonus5 = new ConsumableBonus(consumable5, ConsumableBonus.Attribute.intelligence, 70, 140);
//		consumableBonus5 = consumableBonusDao.create(consumableBonus5);
//		
//		ConsumableBonus consumableBonus6 = new ConsumableBonus(consumable6, ConsumableBonus.Attribute.mind, 80, 160);
//		consumableBonus6 = consumableBonusDao.create(consumableBonus6);
//		
//		ConsumableBonus consumableBonus7 = new ConsumableBonus(consumable7, ConsumableBonus.Attribute.determination, 90, 180);
//		consumableBonus7 = consumableBonusDao.create(consumableBonus7);
//		
//		ConsumableBonus consumableBonus8 = new ConsumableBonus(consumable8, ConsumableBonus.Attribute.defense, 100, 200);
//		consumableBonus8 = consumableBonusDao.create(consumableBonus8);
//		
//		ConsumableBonus consumableBonus9 = new ConsumableBonus(consumable9, ConsumableBonus.Attribute.magicDefense, 110, 220);
//		consumableBonus9 = consumableBonusDao.create(consumableBonus9);
//		
//		ConsumableBonus consumableBonus10 = new ConsumableBonus(consumable10, ConsumableBonus.Attribute.tenacity, 120, 240);
//		consumableBonus10 = consumableBonusDao.create(consumableBonus10);
//	
//		
//		// Methods
//		Item retrievedItem1 = itemDao.getItemByitemID(item1.getItemID());
//		System.out.format("Reading item1: itemID:%d name:%s maxStackSize:%d price:%.2f itemLevel:%d%n",
//		        retrievedItem1.getItemID(), retrievedItem1.getName(), retrievedItem1.getMaxStackSize(), retrievedItem1.getPrice(), retrievedItem1.getItemLevel());
//
//		Item retrievedItem2 = itemDao.getItemByitemID(item2.getItemID());
//		System.out.format("Reading item2: itemID:%d name:%s maxStackSize:%d price:%.2f itemLevel:%d%n",
//		        retrievedItem2.getItemID(), retrievedItem2.getName(), retrievedItem2.getMaxStackSize(), retrievedItem2.getPrice(), retrievedItem2.getItemLevel());
//
//		Item retrievedItem3 = itemDao.getItemByitemID(item3.getItemID());
//		System.out.format("Reading item3: itemID:%d name:%s maxStackSize:%d price:%.2f itemLevel:%d%n",
//		        retrievedItem3.getItemID(), retrievedItem3.getName(), retrievedItem3.getMaxStackSize(), retrievedItem3.getPrice(), retrievedItem3.getItemLevel());
//
//		
//		
//		
//		Gear retrievedGear1 = gearDao.getGearByItemID(gear1.getItemID());
//		System.out.format("Reading retrievedGear1: gearID:%d, name:%s, maxStackSize:%d, price:%.2f, itemLevel:%d, requiredBodySlot:%s, defenseRating:%d, magicDefense:%d, requiredLevel:%d%n",
//		        retrievedGear1.getItemID(), retrievedGear1.getName(), retrievedGear1.getMaxStackSize(), retrievedGear1.getPrice(), retrievedGear1.getItemLevel(), retrievedGear1.getBodySlot(), retrievedGear1.getDefenseRating(), retrievedGear1.getMagicDefenseRating(), retrievedGear1.getRequiredLevel());
//
//		Gear retrievedGear2 = gearDao.getGearByItemID(gear2.getItemID());
//		System.out.format("Reading retrievedGear2: gearID:%d, name:%s, maxStackSize:%d, price:%.2f, itemLevel:%d, requiredBodySlot:%s, defenseRating:%d, magicDefense:%d, requiredLevel:%d%n",
//		        retrievedGear2.getItemID(), retrievedGear2.getName(), retrievedGear2.getMaxStackSize(), retrievedGear2.getPrice(), retrievedGear2.getItemLevel(), retrievedGear2.getBodySlot(), retrievedGear2.getDefenseRating(), retrievedGear2.getMagicDefenseRating(), retrievedGear2.getRequiredLevel());
//
//		Gear retrievedGear3 = gearDao.getGearByItemID(gear3.getItemID());
//		System.out.format("Reading retrievedGear3: gearID:%d, name:%s, maxStackSize:%d, price:%.2f, itemLevel:%d, requiredBodySlot:%s, defenseRating:%d, magicDefense:%d, requiredLevel:%d%n",
//		        retrievedGear3.getItemID(), retrievedGear3.getName(), retrievedGear3.getMaxStackSize(), retrievedGear3.getPrice(), retrievedGear3.getItemLevel(), retrievedGear3.getBodySlot(), retrievedGear3.getDefenseRating(), retrievedGear3.getMagicDefenseRating(), retrievedGear3.getRequiredLevel());
//
//		
//		
//		Weapon retrievedWeapon1 = weaponDao.getWeaponByItemID(weapon1.getItemID());
//		System.out.format("Reading retrievedWeapon1: itemID:%d, name:%s, maxStackSize:%d, price:%.2f, itemLevel:%d, physicalDamage:%d, magicDamage:%d, autoAttack:%d, delay:%d, requiredLevel:%d%n",
//		        retrievedWeapon1.getItemID(), retrievedWeapon1.getName(), retrievedWeapon1.getMaxStackSize(), retrievedWeapon1.getPrice(), retrievedWeapon1.getItemLevel(),
//		        retrievedWeapon1.getPhysicalDamage(), retrievedWeapon1.getMagicDamage(), retrievedWeapon1.getAutoAttack(), retrievedWeapon1.getDelay(), retrievedWeapon1.getRequiredLevel());
//		
//		// method: getWeaponsListByItemLevel
//		
//		List<Weapon> retrievedWeapons = weaponDao.getWeaponsListByItemLevel(10);
//		for (Weapon w : retrievedWeapons) {
//		    System.out.format("Weapon: itemID=%d, name=%s, maxStackSize=%d, price=%.2f, itemLevel=%d, physicalDamage=%d, magicDamage=%d, autoAttack=%d, delay=%d, requiredLevel=%d%n",
//		        w.getItemID(), w.getName(), w.getMaxStackSize(), w.getPrice(), w.getItemLevel(), w.getPhysicalDamage(), w.getMagicDamage(), w.getAutoAttack(), w.getDelay(), w.getRequiredLevel());
//		}
//
//		Weapon retrievedWeapon2 = weaponDao.getWeaponByItemID(weapon2.getItemID());
//		System.out.format("Reading retrievedWeapon2: itemID:%d, name:%s, maxStackSize:%d, price:%.2f, itemLevel:%d, physicalDamage:%d, magicDamage:%d, autoAttack:%d, delay:%d, requiredLevel:%d%n",
//		        retrievedWeapon2.getItemID(), retrievedWeapon2.getName(), retrievedWeapon2.getMaxStackSize(), retrievedWeapon2.getPrice(), retrievedWeapon2.getItemLevel(),
//		        retrievedWeapon2.getPhysicalDamage(), retrievedWeapon2.getMagicDamage(), retrievedWeapon2.getAutoAttack(), retrievedWeapon2.getDelay(), retrievedWeapon2.getRequiredLevel());
//
//		Weapon retrievedWeapon3 = weaponDao.getWeaponByItemID(weapon3.getItemID());
//		System.out.format("Reading retrievedWeapon3: itemID:%d, name:%s, maxStackSize:%d, price:%.2f, itemLevel:%d, physicalDamage:%d, magicDamage:%d, autoAttack:%d, delay:%d, requiredLevel:%d%n",
//		        retrievedWeapon3.getItemID(), retrievedWeapon3.getName(), retrievedWeapon3.getMaxStackSize(), retrievedWeapon3.getPrice(), retrievedWeapon3.getItemLevel(),
//		        retrievedWeapon3.getPhysicalDamage(), retrievedWeapon3.getMagicDamage(), retrievedWeapon3.getAutoAttack(), retrievedWeapon3.getDelay(), retrievedWeapon3.getRequiredLevel());
//		
//		// method: update 
//		weapon1 = weaponDao.updateWeapon(weapon1, 20);
//		System.out.println("Updated weapon1's required level to " + weapon1.getRequiredLevel());
//
//		weapon2 = weaponDao.updateWeapon(weapon2, 20);
//		System.out.println("Updated weapon2's required level to " + weapon2.getRequiredLevel());
//
//		// method: delete
//
//		weaponDao.deleteWeapon(weapon2);
//		System.out.println("Deleted weapon2 from the database.");
//
//
//		Consumable retrievedConsumable1 = consumableDao.getConsumableByItemID(consumable1.getItemID());
//		System.out.format("Reading retrievedConsumable1: itemID:%d, description:%s%n", retrievedConsumable1.getItemID(), retrievedConsumable1.getDescription());
//
//		Consumable retrievedConsumable2 = consumableDao.getConsumableByItemID(consumable2.getItemID());
//		System.out.format("Reading retrievedConsumable2: itemID:%d, description:%s%n", retrievedConsumable2.getItemID(), retrievedConsumable2.getDescription());
//
//		Consumable retrievedConsumable3 = consumableDao.getConsumableByItemID(consumable3.getItemID());
//		System.out.format("Reading retrievedConsumable3: itemID:%d, description:%s%n", retrievedConsumable3.getItemID(), retrievedConsumable3.getDescription());
//
//		
//		
//		Player retrievedPlayer1 = playerDao.getPlayerByID(player1.getPlayerID());
//		System.out.format("Reading player1: playerID:%d, username:%s, emailAddress:%s%n",
//		        retrievedPlayer1.getPlayerID(), retrievedPlayer1.getUsername(), retrievedPlayer1.getEmailAddress());
//
//		Player retrievedPlayer2 = playerDao.getPlayerByID(player2.getPlayerID());
//		System.out.format("Reading player2: playerID:%d, username:%s, emailAddress:%s%n",
//		        retrievedPlayer2.getPlayerID(), retrievedPlayer2.getUsername(), retrievedPlayer2.getEmailAddress());
//
//		Player retrievedPlayer3 = playerDao.getPlayerByID(player3.getPlayerID());
//		System.out.format("Reading player3: playerID:%d, username:%s, emailAddress:%s%n",
//		        retrievedPlayer3.getPlayerID(), retrievedPlayer3.getUsername(), retrievedPlayer3.getEmailAddress());
//
//		
////		Character retrievedCharacter1 = characterDao.getCharacterByCharacterID(character1.getCharacterID());
////		System.out.format("Reading character1: characterID:%d, playerID:%d, firstName:%s, lastName:%s, mainHandWeapon:%d%n",
////		        retrievedCharacter1.getCharacterID(), retrievedCharacter1.getPlayer().getPlayerID(), retrievedCharacter1.getFirstName(), retrievedCharacter1.getLastName(), retrievedCharacter1.getMainHandWeapon());
////
////		Character retrievedCharacter2 = characterDao.getCharacterByCharacterID(character2.getCharacterID());
////		System.out.format("Reading character2: characterID:%d, playerID:%d, firstName:%s, lastName:%s, mainHandWeapon:%d%n",
////		        retrievedCharacter2.getCharacterID(), retrievedCharacter2.getPlayer().getPlayerID(), retrievedCharacter2.getFirstName(), retrievedCharacter2.getLastName(), retrievedCharacter2.getMainHandWeapon());
//
// 
//		Character retrievedCharacter3 = characterDao.getCharacterByCharacterID(character3.getCharacterID());
//		System.out.format("Reading character3: characterID:%d, playerID:%d, firstName:%s, lastName:%s, mainHandWeapon:%d%n",
//		        retrievedCharacter3.getCharacterID(), retrievedCharacter3.getPlayer().getPlayerID(), retrievedCharacter3.getFirstName(), retrievedCharacter3.getLastName(), retrievedCharacter3.getMainHandWeapon().getItemID());
//		
//		// Assuming currencyDao is an instance of CurrencyDao
//		Currency retrievedCurrency1 = currencyDao.getCurrencyByID(currency1.getCurrencyID());
//		System.out.format("Currency1: ID=%d, Name=%s, Description=%s, Cap=%d, WeeklyCap=%d%n",
//		        retrievedCurrency1.getCurrencyID(), retrievedCurrency1.getName(), retrievedCurrency1.getDescription(), retrievedCurrency1.getCap(), retrievedCurrency1.getWeeklyCap());
//
//		Currency retrievedCurrency2 = currencyDao.getCurrencyByID(currency2.getCurrencyID());
//		System.out.format("Currency2: ID=%d, Name=%s, Description=%s, Cap=%d, WeeklyCap=%d%n",
//		        retrievedCurrency2.getCurrencyID(), retrievedCurrency2.getName(), retrievedCurrency2.getDescription(), retrievedCurrency2.getCap(), retrievedCurrency2.getWeeklyCap());
//
//		Currency retrievedCurrency3 = currencyDao.getCurrencyByID(currency3.getCurrencyID());
//		System.out.format("Currency3: ID=%d, Name=%s, Description=%s, Cap=%d, WeeklyCap=%d%n",
//		        retrievedCurrency3.getCurrencyID(), retrievedCurrency3.getName(), retrievedCurrency3.getDescription(), retrievedCurrency3.getCap(), retrievedCurrency3.getWeeklyCap());
//
//		
//		// Assuming characterCurrencyDao is an instance of CharacterCurrencyDao
//		CharacterCurrency retrievedCharacterCurrency1 = characterCurrencyDao.getCharacterCurrencyByID(character1.getCharacterID(), currency1.getCurrencyID());
//		System.out.format("CharacterCurrency1: CharacterID=%d, CurrencyID=%d, OwnedAmount=%d, WeeklyOwnedAmount=%d%n",
//		        retrievedCharacterCurrency1.getCharacter().getCharacterID(), retrievedCharacterCurrency1.getCurrency().getCurrencyID(), retrievedCharacterCurrency1.getOwnedAmount(), retrievedCharacterCurrency1.getWeeklyOwnedAmount());
//
//		CharacterCurrency retrievedCharacterCurrency2 = characterCurrencyDao.getCharacterCurrencyByID(character2.getCharacterID(), currency2.getCurrencyID());
//		System.out.format("CharacterCurrency2: CharacterID=%d, CurrencyID=%d, OwnedAmount=%d, WeeklyOwnedAmount=%d%n",
//		        retrievedCharacterCurrency2.getCharacter().getCharacterID(), retrievedCharacterCurrency2.getCurrency().getCurrencyID(), retrievedCharacterCurrency2.getOwnedAmount(), retrievedCharacterCurrency2.getWeeklyOwnedAmount());
//
//		CharacterCurrency retrievedCharacterCurrency3 = characterCurrencyDao.getCharacterCurrencyByID(character3.getCharacterID(), currency3.getCurrencyID());
//		System.out.format("CharacterCurrency3: CharacterID=%d, CurrencyID=%d, OwnedAmount=%d, WeeklyOwnedAmount=%d%n",
//		        retrievedCharacterCurrency3.getCharacter().getCharacterID(), retrievedCharacterCurrency3.getCurrency().getCurrencyID(), retrievedCharacterCurrency3.getOwnedAmount(), retrievedCharacterCurrency3.getWeeklyOwnedAmount());
//
//		EquipedGear retrievedEquipedGear1 = equipedGearDao.getGearByCharacterAndBodySlot(character1.getCharacterID(), EquipedGear.BodySlot.head);
//		System.out.format("Equipped Gear1: CharacterID=%d, BodySlot=%s, ItemID=%d%n",
//		        retrievedEquipedGear1.getCharacter().getCharacterID(), retrievedEquipedGear1.getBodySlot(), retrievedEquipedGear1.getItem().getItemID());
//
//		EquipedGear retrievedEquipedGear2 = equipedGearDao.getGearByCharacterAndBodySlot(character2.getCharacterID(), EquipedGear.BodySlot.body);
//		System.out.format("Equipped Gear2: CharacterID=%d, BodySlot=%s, ItemID=%d%n",
//		        retrievedEquipedGear2.getCharacter().getCharacterID(), retrievedEquipedGear2.getBodySlot(), retrievedEquipedGear2.getItem().getItemID());
//
//		EquipedGear retrievedEquipedGear3 = equipedGearDao.getGearByCharacterAndBodySlot(character3.getCharacterID(), EquipedGear.BodySlot.hand);
//		System.out.format("Equipped Gear3: CharacterID=%d, BodySlot=%s, ItemID=%d%n",
//		        retrievedEquipedGear3.getCharacter().getCharacterID(), retrievedEquipedGear3.getBodySlot(), retrievedEquipedGear3.getItem().getItemID());
//
//		
//		CharacterItem retrievedCharacterItem1 = characterItemDao.getCharacterByCharacterIDAndSlotID(character1.getCharacterID(), 1);
//		System.out.format("CharacterItem1: CharacterID=%d, SlotID=%d, ItemID=%d, Quantity=%d%n",
//				retrievedCharacterItem1.getCharacter().getCharacterID(), retrievedCharacterItem1.getSlotID(), retrievedCharacterItem1.getItem().getItemID(), retrievedCharacterItem1.getQuantity());
//
//		CharacterItem retrievedCharacterItem2 = characterItemDao.getCharacterByCharacterIDAndSlotID(character2.getCharacterID(), 2);
//		System.out.format("CharacterItem2: CharacterID=%d, SlotID=%d, ItemID=%d, Quantity=%d%n",
//				retrievedCharacterItem2.getCharacter().getCharacterID(), retrievedCharacterItem2.getSlotID(), retrievedCharacterItem2.getItem().getItemID(), retrievedCharacterItem2.getQuantity());
//
//		CharacterItem retrievedCharacterItem3 = characterItemDao.getCharacterByCharacterIDAndSlotID(character3.getCharacterID(), 3);
//		System.out.format("CharacterItem3: CharacterID=%d, SlotID=%d, ItemID=%d, Quantity=%d%n",
//				retrievedCharacterItem3.getCharacter().getCharacterID(), retrievedCharacterItem3.getSlotID(), retrievedCharacterItem3.getItem().getItemID(), retrievedCharacterItem3.getQuantity());
//
//		
//		// Test getJobByID
//		Job retrievedJob1 = jobDao.getJobByID(job1.getJobID());
//		System.out.format("Job1: jobID=%d, name=%s, description=%s%n",
//		        retrievedJob1.getJobID(), retrievedJob1.getName(), retrievedJob1.getDescription());
//
//		Job retrievedJob2 = jobDao.getJobByID(job2.getJobID());
//		System.out.format("Job2: jobID=%d, name=%s, description=%s%n",
//		        retrievedJob2.getJobID(), retrievedJob2.getName(), retrievedJob2.getDescription());
//
//		Job retrievedJob3 = jobDao.getJobByID(job3.getJobID());
//		System.out.format("Job3: jobID=%d, name=%s, description=%s%n",
//		        retrievedJob3.getJobID(), retrievedJob3.getName(), retrievedJob3.getDescription());
//
//		// Test CharacterJob
//		CharacterJob retrievedCharacterJob1 = characterJobDao.getCharacterJobByID(character1.getCharacterID(), job1.getJobID());
//		System.out.format("CharacterJob1: characterID=%d, jobID=%d, level=%d%n",
//		        character1.getCharacterID(), job1.getJobID(), retrievedCharacterJob1.getLevel());
//
//		CharacterJob retrievedCharacterJob2 = characterJobDao.getCharacterJobByID(character2.getCharacterID(), job2.getJobID());
//		System.out.format("CharacterJob2: characterID=%d, jobID=%d, level=%d%n",
//		        character2.getCharacterID(), job2.getJobID(), retrievedCharacterJob2.getLevel());
//
//		CharacterJob retrievedCharacterJob3 = characterJobDao.getCharacterJobByID(character3.getCharacterID(), job3.getJobID());
//		System.out.format("CharacterJob3: characterID=%d, jobID=%d, level=%d%n",
//		        character3.getCharacterID(), job3.getJobID(), retrievedCharacterJob3.getLevel());
//
//		// Test GearAllowedJob
//		GearAllowedJob retrievedGearAllowedJob1 = gearAllowedJobDao.getGearAllowedJobByID(job1.getJobID(), gear1.getItemID());
//		System.out.format("GearAllowedJob1: jobID=%d, gearID=%d%n",
//		        job1.getJobID(), gear1.getItemID());
//
//		GearAllowedJob retrievedGearAllowedJob2 = gearAllowedJobDao.getGearAllowedJobByID(job2.getJobID(), gear2.getItemID());
//		System.out.format("GearAllowedJob2: jobID=%d, gearID=%d%n",
//		        job2.getJobID(), gear2.getItemID());
//
//		GearAllowedJob retrievedGearAllowedJob3 = gearAllowedJobDao.getGearAllowedJobByID(job3.getJobID(), gear3.getItemID());
//		System.out.format("GearAllowedJob3: jobID=%d, gearID=%d%n",
//		        job3.getJobID(), gear3.getItemID());
//
//		// Test WeaponAllowedJob
//		WeaponAllowedJob retrievedWeaponAllowedJob1 = weaponAllowedJobDao.getWeaponAllowedJobByID(job1.getJobID(), weapon1.getItemID());
//		System.out.format("WeaponAllowedJob1: jobID=%d, weaponID=%d%n",
//		        job1.getJobID(), weapon1.getItemID());
//
//		WeaponAllowedJob retrievedWeaponAllowedJob2 = weaponAllowedJobDao.getWeaponAllowedJobByID(job2.getJobID(), weapon2.getItemID());
//		System.out.format("WeaponAllowedJob2: jobID=%d, weaponID=%d%n",
//		        job2.getJobID(), weapon2.getItemID());
//
//		WeaponAllowedJob retrievedWeaponAllowedJob3 = weaponAllowedJobDao.getWeaponAllowedJobByID(job3.getJobID(), weapon3.getItemID());
//		System.out.format("WeaponAllowedJob3: jobID=%d, weaponID=%d%n",
//		        job3.getJobID(), weapon3.getItemID());
//
//		
//		// Test CharacterAttribute retrieval
//		CharacterAttribute retrievedCharacterAttribute1 = characterAttributeDao.getCharacterAttributeByCharacterIDAndAttribute(character1.getCharacterID(), CharacterAttribute.Attribute.strength);
//		System.out.format("CharacterAttribute1: CharacterID=%d, Attribute=%s, Value=%d%n",
//		        retrievedCharacterAttribute1.getCharacter().getCharacterID(), "strength", retrievedCharacterAttribute1.getValue());
//
//		CharacterAttribute retrievedCharacterAttribute2 = characterAttributeDao.getCharacterAttributeByCharacterIDAndAttribute(character2.getCharacterID(), CharacterAttribute.Attribute.dexterity);
//		System.out.format("CharacterAttribute2: CharacterID=%d, Attribute=%s, Value=%d%n",
//		        retrievedCharacterAttribute2.getCharacter().getCharacterID(), "dexterity", retrievedCharacterAttribute2.getValue());
//
//		CharacterAttribute retrievedCharacterAttribute3 = characterAttributeDao.getCharacterAttributeByCharacterIDAndAttribute(character3.getCharacterID(), CharacterAttribute.Attribute.intelligence);
//		System.out.format("CharacterAttribute3: CharacterID=%d, Attribute=%s, Value=%d%n",
//		        retrievedCharacterAttribute3.getCharacter().getCharacterID(), "intelligence", retrievedCharacterAttribute3.getValue());
//
//		// Test GearBonus retrieval
//		GearBonus retrievedGearBonus1 = gearBonusDao.getGearBonusByGearIDAndAttribute(gear1.getItemID(), GearBonus.Attribute.strength);
//		System.out.format("GearBonus1: GearID=%d, Attribute=%s, Bonus=%d%n",
//		        gear1.getItemID(), "strength", retrievedGearBonus1.getBonus());
//
//		GearBonus retrievedGearBonus2 = gearBonusDao.getGearBonusByGearIDAndAttribute(gear2.getItemID(), GearBonus.Attribute.dexterity);
//		System.out.format("GearBonus2: GearID=%d, Attribute=%s, Bonus=%d%n",
//		        gear2.getItemID(), "dexterity", retrievedGearBonus2.getBonus());
//
//		GearBonus retrievedGearBonus3 = gearBonusDao.getGearBonusByGearIDAndAttribute(gear3.getItemID(), GearBonus.Attribute.intelligence);
//		System.out.format("GearBonus3: GearID=%d, Attribute=%s, Bonus=%d%n",
//		        gear3.getItemID(), "intelligence", retrievedGearBonus3.getBonus());
//
//		// Test WeaponBonus retrieval
//		
//		// Cannot invoke "game.model.WeaponBonus.getBonus()" because "retrievedWeaponBonus1" is null
////		WeaponBonus retrievedWeaponBonus1 = weaponBonusDao.getWeaponBonusByWeaponIDAndAttribute(weapon1.getItemID(), WeaponBonus.Attribute.attackPower);
////		System.out.format("WeaponBonus1: WeaponID=%d, Attribute=%s, Bonus=%d%n",
////		        weapon1.getItemID(), "attackPower", retrievedWeaponBonus1.getBonus());
//
////		WeaponBonus retrievedWeaponBonus2 = weaponBonusDao.getWeaponBonusByWeaponIDAndAttribute(weapon2.getItemID(), WeaponBonus.Attribute.spellSpeed);
////		System.out.format("WeaponBonus2: WeaponID=%d, Attribute=%s, Bonus=%d%n",
////		        weapon2.getItemID(), "spellSpeed", retrievedWeaponBonus2.getBonus());
//
//		WeaponBonus retrievedWeaponBonus3 = weaponBonusDao.getWeaponBonusByWeaponIDAndAttribute(weapon3.getItemID(), WeaponBonus.Attribute.criticalHit);
//		System.out.format("WeaponBonus3: WeaponID=%d, Attribute=%s, Bonus=%d%n",
//		        weapon3.getItemID(), "criticalHit", retrievedWeaponBonus3.getBonus());
//
//		// Test ConsumableBonus retrieval
//		ConsumableBonus retrievedConsumableBonus1 = consumableBonusDao.getConsumableBonusByConsumableIDAndAttribute(consumable1.getItemID(), ConsumableBonus.Attribute.vitality);
//		System.out.format("ConsumableBonus1: ConsumableID=%d, Attribute=%s, Bonus=%d, Cap=%d%n",
//		        consumable1.getItemID(), "vitality", retrievedConsumableBonus1.getBonus(), retrievedConsumableBonus1.getCap());
//
//		ConsumableBonus retrievedConsumableBonus2 = consumableBonusDao.getConsumableBonusByConsumableIDAndAttribute(consumable2.getItemID(), ConsumableBonus.Attribute.mind);
//		System.out.format("ConsumableBonus2: ConsumableID=%d, Attribute=%s, Bonus=%d, Cap=%d%n",
//		        consumable2.getItemID(), "mind", retrievedConsumableBonus2.getBonus(), retrievedConsumableBonus2.getCap());
//
//		ConsumableBonus retrievedConsumableBonus3 = consumableBonusDao.getConsumableBonusByConsumableIDAndAttribute(consumable3.getItemID(), ConsumableBonus.Attribute.determination);
//		System.out.format("ConsumableBonus3: ConsumableID=%d, Attribute=%s, Bonus=%d, Cap=%d%n",
//		        consumable3.getItemID(), "determination", retrievedConsumableBonus3.getBonus(), retrievedConsumableBonus3.getCap());
//
//		
//
//	}
//}
